const NUI_COMPANY = {
    name: 'New Urban Influence',
    phone: '(248) 487-8747',
    email: 'info@newurbaninfluence.com',
    location: 'Detroit, MI',
    website: 'newurbaninfluence.com',
    colors: {
        primary: '#e63946',
        secondary: '#1a1a1a',
        accent: '#f4f4f4'
    },
    logo: 'NUI | New Urban Influence' // Text logo for now
};

// Email Templates Storage
let emailTemplates = JSON.parse(localStorage.getItem('nui_email_templates')) || [];
let scheduledEmails = JSON.parse(localStorage.getItem('nui_scheduled_emails')) || [];
function saveEmailTemplates() { localStorage.setItem('nui_email_templates', JSON.stringify(emailTemplates)); }
function saveScheduledEmails() { localStorage.setItem('nui_scheduled_emails', JSON.stringify(scheduledEmails)); }

// Initialize default templates
if (emailTemplates.length === 0) {
    emailTemplates = [
        {
            id: 1,
            name: 'Welcome New Client',
            subject: 'Welcome to the NUI Family, {{clientName}}!',
            category: 'onboarding',
            body: `Hey {{clientName}},

Let me be real with you — you just made one of the smartest decisions for your business.

While your competitors are out there playing small, you chose to invest in a brand that actually WORKS. That takes vision. That takes guts. And honestly? That's exactly the type of client we love working with.

Here's what happens next:
• Your dedicated designer will reach out within 24 hours
• We'll dive deep into your brand strategy
• You'll start seeing concepts within 72 hours

This isn't just another design project. This is the beginning of your business transformation.

Stay hungry. Stay focused. And get ready to dominate.

Let's build something legendary.`
        },
        {
            id: 2,
            name: 'Project Kickoff',
            subject: '🚀 Your Project Just Started, {{clientName}}!',
            category: 'project',
            body: `Hey {{clientName}},

Game time.

Your project is officially in motion, and I want you to understand something important: we don't do average work. We create brands that make your competition nervous.

Your designer {{designerName}} is already working on bringing your vision to life.

What to expect:
• First proof delivery: 72 hours
• Unlimited revisions until you're 100% satisfied
• Direct communication the entire way

Here's my challenge to you: dream bigger than you think you should. Push us. Tell us what you REALLY want your brand to feel like. The bolder you go, the more we can deliver.

Time to level up.`
        },
        {
            id: 3,
            name: 'Proof Ready',
            subject: '👀 Your Proof is Ready for Review, {{clientName}}',
            category: 'project',
            body: `Hey {{clientName}},

Stop what you're doing.

Your first proof is ready, and I'm genuinely excited for you to see it. This is the moment where your brand starts becoming REAL.

Log into your client portal to review:
{{portalLink}}

Here's what I need from you:
1. Look at it with fresh eyes
2. Imagine it on your website, your business cards, everywhere
3. Trust your gut reaction

Love it? Approve it and we move forward.
Want changes? No problem — tell us exactly what you're thinking.

This is YOUR brand. Make sure it feels right.

Waiting on your feedback.`
        },
        {
            id: 4,
            name: 'Invoice Reminder',
            subject: 'Quick Reminder: Invoice {{invoiceNumber}} Due Soon',
            category: 'payment',
            body: `Hey {{clientName}},

Quick heads up — your invoice {{invoiceNumber}} for \${{amount}} is coming due.

I know you're busy building your empire, so I wanted to make this easy. Click below to handle it in 30 seconds:

{{paymentLink}}

Once this is squared away, we can keep the momentum going on your project. No delays, no interruptions — just results.

Questions? Hit reply. I got you.

Talk soon.`
        },
        {
            id: 5,
            name: 'Project Complete',
            subject: '🎉 Your Brand is LIVE, {{clientName}}!',
            category: 'delivery',
            body: `Hey {{clientName}},

This is it. The moment you've been waiting for.

Your brand is complete, approved, and ready to take over your market. All your files are waiting in your portal:
{{portalLink}}

But here's what I really want you to understand...

This isn't the end. This is the BEGINNING.

You now have a brand that:
• Commands attention
• Builds instant credibility
• Makes people remember you

Now it's time to USE it. Put it everywhere. Be loud. Be consistent. And watch what happens to your business.

It's been an honor working with you. And remember — we're always here when you're ready to level up again.

Go dominate.`
        },
        {
            id: 6,
            name: 'Holiday Greeting',
            subject: 'Happy Holidays from the NUI Family! 🎄',
            category: 'newsletter',
            body: `Hey {{clientName}},

As the year wraps up, I wanted to take a moment to say something that doesn't get said enough:

THANK YOU.

Thank you for trusting us with your brand. Thank you for dreaming big. Thank you for being part of the NUI family.

This year, we helped brands just like yours stand out, get noticed, and grow. And honestly? It never gets old.

Wishing you and your family an incredible holiday season filled with rest, reflection, and maybe a little strategic planning for next year 😉

Here's to an even bigger year ahead.

Happy Holidays!`
        },
        {
            id: 7,
            name: 'New Year Special',
            subject: '2026 is YOUR Year, {{clientName}} — Let\'s Make It Happen',
            category: 'promo',
            body: `Hey {{clientName}},

New year. New opportunity. Same question:

Are you going to play small, or are you going to DOMINATE?

Look, I'm not here to give you some generic "new year, new you" message. I'm here to tell you that the brands who win in 2026 are the ones taking action NOW.

That's why we're offering something special:
🔥 20% off any branding package this month
🔥 Free brand strategy session ($500 value)
🔥 Priority scheduling for Q1 delivery

This isn't about discounts. This is about momentum. The businesses that start strong, finish strong.

Ready to make 2026 your year?

Reply "LET'S GO" and I'll personally set up your strategy call.

No excuses. Just results.`
        }
    ];
    saveEmailTemplates();
}

// Generate email HTML with beautiful template
function generateEmailHTML(template, clientData) {
    const { clientName, designerName, invoiceNumber, amount, paymentLink, portalLink } = clientData;

    let body = template.body
        .replace(/\{\{clientName\}\}/g, clientName || 'there')
        .replace(/\{\{designerName\}\}/g, designerName || 'our team')
        .replace(/\{\{invoiceNumber\}\}/g, invoiceNumber || '')
        .replace(/\{\{amount\}\}/g, amount || '')
        .replace(/\{\{paymentLink\}\}/g, paymentLink || '#')
        .replace(/\{\{portalLink\}\}/g, portalLink || '#');

    // Convert line breaks to HTML
    const bodyHTML = body.split('\n\n').map(p => `<p style="margin: 0 0 16px 0; line-height: 1.7;">${p.replace(/\n/g, '<br>')}</p>`).join('');

    return `
<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Geo Meta Tags -->
    <meta name="geo.region" content="US-MI">
    <meta name="geo.placename" content="Detroit, Michigan">
    <meta name="geo.position" content="42.3314;-83.0458">
    <meta name="ICBM" content="42.3314, -83.0458">
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f4; font-family: 'Helvetica Neue', Arial, sans-serif;">
 <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f4; padding: 40px 20px;">
<tr>
<td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.1);">
                    <!-- Header -->
<tr>
<td style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); padding: 32px 40px; text-align: center;">
<h2 style="margin: 0; font-size: 28px; font-weight: 800; color: #e63946; letter-spacing: 2px;">NUI</h2>
<p style="margin: 8px 0 0 0; font-size: 11px; color: #888; letter-spacing: 3px; text-transform: uppercase;">New Urban Influence</p>
</td>
</tr>
                    <!-- Accent Bar -->
<tr>
<td style="background: linear-gradient(90deg, #e63946, #ff6b6b); height: 4px;"></td>
</tr>
                    <!-- Body -->
<tr>
<td style="padding: 48px 40px; color: #1a1a1a; font-size: 16px;">
                            ${bodyHTML}
</td>
</tr>
                    <!-- Signature -->
<tr>
<td style="padding: 0 40px 40px 40px;">
<table width="100%" cellpadding="0" cellspacing="0" style="border-top: 1px solid #eee; padding-top: 24px;">
<tr>
<td>
<p style="margin: 0 0 4px 0; font-weight: 700; color: #1a1a1a;">New Urban Influence</p>
<p style="margin: 0; font-size: 14px; color: #666;">Detroit's Premier Creative Agency</p>
<p style="margin: 12px 0 0 0; font-size: 14px; color: #888;">
                                            📞 ${NUI_COMPANY.phone}<br>
                                            📧 ${NUI_COMPANY.email}<br>
                                            📍 ${NUI_COMPANY.location}
</p>
</td>
</tr>
</table>
</td>
</tr>
                    <!-- Footer -->
<tr>
<td style="background-color: #1a1a1a; padding: 24px 40px; text-align: center;">
<p style="margin: 0; font-size: 12px; color: #888;">
                                © 2026 New Urban Influence. Unapologetically Detroit.
</p>
<p style="margin: 12px 0 0 0; font-size: 11px; color: #666;">
<a href="#" style="color: #e63946; text-decoration: none;">Website</a> ·
<a href="#" style="color: #e63946; text-decoration: none;">Instagram</a> ·
<a href="#" style="color: #e63946; text-decoration: none;">Unsubscribe</a>
</p>
</td>
</tr>
</table>
</td>
</tr>
 </table>
</body>
</html>`;
}

// Send email using template
async function sendTemplateEmail(templateId, clientId, customData = {}) {
    const template = emailTemplates.find(t => t.id === templateId);
    const client = clients.find(c => c.id === clientId);

    if (!template || !client) {
        alert('Template or client not found');
        return;
    }

    const clientData = {
        clientName: client.name,
        portalLink: window.location.origin + '/portal',
        ...customData
    };

    const subject = template.subject.replace(/\{\{clientName\}\}/g, client.name);
    const html = generateEmailHTML(template, clientData);

    try {
        const response = await fetch('/.netlify/functions/send-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                to: client.email,
                subject: subject,
                html: html,
                text: template.body.replace(/\{\{clientName\}\}/g, client.name),
                clientId: client.id
            })
        });

        const result = await response.json();
        if (result.success) {
            alert('Email sent successfully!');
        } else {
            throw new Error(result.error);
        }
    } catch (error) {
        console.error('Email error:', error);
        alert('Email sending failed. Check console for details.');
    }
}

// Load Email Templates Panel in Admin
function loadAdminEmailTemplatesPanel() {
    const categories = ['onboarding', 'project', 'payment', 'delivery', 'newsletter', 'promo'];

    document.getElementById('adminEmailmarketingPanel').innerHTML = `
<div class="flex-between mb-24">
<h2 class="fs-28 fw-700">📧 Email Templates</h2>
<button onclick="showCreateTemplateModal()" class="btn-cta">+ New Template</button>
</div>

        <!-- Quick Send -->
<div style="background: linear-gradient(135deg, #1a1a1a, #2d2d2d); padding: 24px; border-radius: 12px; margin-bottom: 24px;">
<h3 style="margin: 0 0 16px 0; color: #fff;">⚡ Quick Send</h3>
<div class="flex-gap-12 flex-wrap">
<select id="quickSendTemplate" style="flex: 1; min-width: 200px; padding: 12px; background: #333; border: 1px solid #444; color: #fff; border-radius: 8px;">
<option value="">Select Template</option>
                    ${emailTemplates.map(t => `<option value="${t.id}">${t.name}</option>`).join('')}
</select>
<select id="quickSendClient" style="flex: 1; min-width: 200px; padding: 12px; background: #333; border: 1px solid #444; color: #fff; border-radius: 8px;">
<option value="">Select Client</option>
                    ${clients.map(c => `<option value="${c.id}">${c.name} (${c.email})</option>`).join('')}
</select>
<button onclick="quickSendEmail()" style="padding: 12px 24px; background: #e63946; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Send Now</button>
<button onclick="previewEmail()" style="padding: 12px 24px; background: #333; color: #fff; border: 1px solid #444; border-radius: 8px; cursor: pointer;">Preview</button>
</div>
</div>

        <!-- Scheduled Campaigns -->
<div style="background: #1c1c1c; padding: 24px; border-radius: 12px; margin-bottom: 24px;">
<div class="admin-row-between">
<h3 class="m-0">🗓️ Scheduled Campaigns</h3>
<button onclick="showScheduleCampaignModal()" style="padding: 8px 16px; background: #10b981; color: #fff; border: none; border-radius: 6px; cursor: pointer;">+ Schedule Campaign</button>
</div>
            ${scheduledEmails.length > 0 ? scheduledEmails.map(s => `
<div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #222;">
<div>
<div style="font-weight: 500;">${emailTemplates.find(t => t.id === s.templateId)?.name || 'Unknown'}</div>
<div class="text-muted-sm">${s.audience === 'all' ? 'All Clients' : s.audience} · ${new Date(s.sendAt).toLocaleString()}</div>
</div>
<div class="flex-gap-8">
<span style="padding: 4px 12px; border-radius: 12px; font-size: 12px; background: ${s.status === 'sent' ? '#10b98120' : '#f59e0b20'}; color: ${s.status === 'sent' ? '#10b981' : '#f59e0b'};">${s.status}</span>
<button onclick="cancelScheduledEmail(${s.id})" style="padding: 4px 8px; background: #333; border: none; color: #888; border-radius: 4px; cursor: pointer;">×</button>
</div>
</div>
            `).join('') : '<p class="text-muted">No scheduled campaigns.</p>'}
</div>

        <!-- Templates by Category -->
        ${categories.map(cat => `
<div class="mb-24">
<h3 style="font-size: 14px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;">${cat}</h3>
<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px;">
                    ${emailTemplates.filter(t => t.category === cat).map(t => `
<div style="background: #1c1c1c; padding: 20px; border-radius: 12px; border: 1px solid #222;">
<h4 style="margin: 0 0 8px 0; font-size: 16px;">${t.name}</h4>
<p style="margin: 0 0 12px 0; font-size: 13px; color: #888; line-height: 1.5;">${t.subject}</p>
<div class="flex-gap-8">
<button onclick="editTemplate(${t.id})" style="flex: 1; padding: 8px; background: #333; border: none; color: #fff; border-radius: 6px; cursor: pointer; font-size: 12px;">Edit</button>
<button onclick="previewTemplate(${t.id})" style="flex: 1; padding: 8px; background: #e63946; border: none; color: #fff; border-radius: 6px; cursor: pointer; font-size: 12px;">Preview</button>
</div>
</div>
                    `).join('')}
</div>
</div>
        `).join('')}

        <!-- Holiday Drip Campaign Templates -->
<div style="margin-top: 32px; border-top: 1px solid #333; padding-top: 24px;">
<div class="flex-between mb-16">
<h3 style="margin: 0; font-size: 18px;">🎄 Holiday Drip Campaign</h3>
<span style="font-size: 12px; color: #666;">8-week countdown · Runs automatically before each US holiday</span>
</div>
<div id="holidayDripTemplates" style="display: grid; gap: 12px;">
<p style="color: #666;">Loading holiday templates...</p>
</div>
</div>
    `;

    // Load holiday drip templates from Supabase
    loadHolidayDripTemplates();
}

// ==================== HOLIDAY DRIP TEMPLATE MANAGEMENT ====================
let holidayDripTemplates = [];

async function loadHolidayDripTemplates() {
    const container = document.getElementById('holidayDripTemplates');
    if (!container) return;
    try {
        const res = await fetch('/.netlify/functions/holiday-templates');
        holidayDripTemplates = await res.json();
        if (!Array.isArray(holidayDripTemplates) || holidayDripTemplates.length === 0) {
            container.innerHTML = '<p style="color: #666;">No holiday templates found. Run the seed SQL in Supabase.</p>';
            return;
        }
        const weekLabels = { 8: '60 days out', 7: '53 days', 6: '46 days', 5: '39 days', 4: '30 days', 3: '21 days', 2: '14 days', 1: '7 days — final week' };
        container.innerHTML = holidayDripTemplates.map(t => `
<div style="background: #1c1c1c; padding: 16px 20px; border-radius: 10px; border: 1px solid #222; display: flex; align-items: center; justify-content: space-between;">
<div style="flex: 1;">
<div style="display: flex; align-items: center; gap: 12px; margin-bottom: 4px;">
<span style="background: #e63946; color: #fff; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 4px;">Week ${9 - t.week_number}</span>
<span style="font-size: 12px; color: #666;">${weekLabels[t.week_number] || ''}</span>
</div>
<h4 style="margin: 0 0 4px 0; font-size: 15px;">${t.subject}</h4>
<p style="margin: 0; font-size: 12px; color: #888; max-width: 500px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${t.body}</p>
</div>
<button onclick="editHolidayDripTemplate(${t.week_number})" style="padding: 8px 16px; background: #333; border: none; color: #fff; border-radius: 6px; cursor: pointer; font-size: 12px;">Edit & Preview</button>
</div>
        `).join('');
    } catch (err) {
        container.innerHTML = '<p style="color: #e63946;">Failed to load holiday templates.</p>';
        console.error('Holiday drip load error:', err);
    }
}

function editHolidayDripTemplate(weekNum) {
    const t = holidayDripTemplates.find(x => x.week_number === weekNum);
    if (!t) return;
    const weekLabel = `Week ${9 - weekNum} (${weekNum === 8 ? '60 days' : weekNum === 1 ? 'Final week' : `${weekNum * 7} days`} before holiday)`;

    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.85);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
    modal.innerHTML = `
<div style="background:#242424;border-radius:16px;width:100%;max-width:1100px;max-height:90vh;overflow-y:auto;padding:32px;">
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
<div>
<h3 style="margin:0 0 4px 0;">🎄 Edit Holiday Drip — ${weekLabel}</h3>
<p style="margin:0;font-size:12px;color:#888;">Use <code style="background:#333;padding:2px 6px;border-radius:4px;">{{holiday}}</code> and <code style="background:#333;padding:2px 6px;border-radius:4px;">{{firstName}}</code> placeholders · Preview updates live</p>
</div>
<button onclick="this.closest('div[style*=fixed]').remove()" style="background:none;border:none;color:#666;font-size:24px;cursor:pointer;padding:0 4px;">✕</button>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
<!-- LEFT: Editor -->
<div>
<label style="display:block;margin-bottom:4px;font-size:13px;color:#aaa;">Subject Line</label>
<input id="hdtSubject" value="${t.subject.replace(/"/g, '&quot;')}" oninput="updateHolidayPreview(${weekNum})" style="width:100%;padding:10px;background:#1c1c1c;border:1px solid #333;color:#fff;border-radius:8px;margin-bottom:14px;box-sizing:border-box;">

<label style="display:block;margin-bottom:4px;font-size:13px;color:#aaa;">Email Heading</label>
<input id="hdtHeading" value="${t.heading.replace(/"/g, '&quot;')}" oninput="updateHolidayPreview(${weekNum})" style="width:100%;padding:10px;background:#1c1c1c;border:1px solid #333;color:#fff;border-radius:8px;margin-bottom:14px;box-sizing:border-box;">

<label style="display:block;margin-bottom:4px;font-size:13px;color:#aaa;">Body Copy</label>
<textarea id="hdtBody" rows="6" oninput="updateHolidayPreview(${weekNum})" style="width:100%;padding:10px;background:#1c1c1c;border:1px solid #333;color:#fff;border-radius:8px;margin-bottom:14px;resize:vertical;box-sizing:border-box;">${t.body}</textarea>

<label style="display:block;margin-bottom:4px;font-size:13px;color:#aaa;">CTA Button Text</label>
<input id="hdtCta" value="${t.cta.replace(/"/g, '&quot;')}" oninput="updateHolidayPreview(${weekNum})" style="width:100%;padding:10px;background:#1c1c1c;border:1px solid #333;color:#fff;border-radius:8px;margin-bottom:20px;box-sizing:border-box;">

<div style="display:flex;gap:12px;">
<button id="hdtSaveBtn" onclick="saveHolidayDripTemplate(${weekNum})" style="flex:1;padding:12px;background:#e63946;border:none;color:#fff;border-radius:8px;cursor:pointer;font-weight:600;">Save Changes</button>
<button onclick="this.closest('div[style*=fixed]').remove()" style="flex:1;padding:12px;background:#333;border:none;color:#fff;border-radius:8px;cursor:pointer;">Cancel</button>
</div>
</div>

<!-- RIGHT: Live Preview -->
<div>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
<span style="font-size:13px;color:#aaa;">📧 Email Preview</span>
<span style="font-size:11px;color:#555;">Subject: <span id="hdtPreviewSubject" style="color:#aaa;">${t.subject.replace(/\{\{holiday\}\}/g, 'Christmas').replace(/\{\{firstName\}\}/g, 'Mike')}</span></span>
</div>
<div id="hdtPreviewContainer" style="background:#222;border-radius:12px;padding:12px;max-height:65vh;overflow-y:auto;border:1px solid #333;">
</div>
</div>
</div>
</div>`;
    document.body.appendChild(modal);
    updateHolidayPreview(weekNum);
}

function updateHolidayPreview(weekNum) {
    const subject = (document.getElementById('hdtSubject')?.value || '').replace(/\{\{holiday\}\}/g, 'Christmas').replace(/\{\{firstName\}\}/g, 'Mike');
    const heading = (document.getElementById('hdtHeading')?.value || '').replace(/\{\{holiday\}\}/g, 'Christmas').replace(/\{\{firstName\}\}/g, 'Mike');
    const body = (document.getElementById('hdtBody')?.value || '').replace(/\{\{holiday\}\}/g, 'Christmas').replace(/\{\{firstName\}\}/g, 'Mike');
    const cta = (document.getElementById('hdtCta')?.value || '').replace(/\{\{holiday\}\}/g, 'Christmas').replace(/\{\{firstName\}\}/g, 'Mike');

    const subjectEl = document.getElementById('hdtPreviewSubject');
    if (subjectEl) subjectEl.textContent = subject;

    const container = document.getElementById('hdtPreviewContainer');
    if (!container) return;

    container.innerHTML = `
    <div style="font-family: Arial, sans-serif; max-width: 100%; margin: 0 auto; background: #1c1c1c; color: #fff; border-radius: 12px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%); padding: 32px 24px; text-align: center;">
            <div style="margin-bottom: 12px;"><span style="font-family: 'Helvetica Neue', Arial, sans-serif; font-weight: 900; font-size: 16px; letter-spacing: 3px; text-transform: uppercase; color: #fff;">NEW URBAN </span><span style="font-family: 'Helvetica Neue', Arial, sans-serif; font-weight: 900; font-size: 16px; letter-spacing: 3px; text-transform: uppercase; color: #dc2626;">INFLUENCE</span><div style="font-family: 'Helvetica Neue', Arial, sans-serif; font-weight: 600; font-size: 8px; letter-spacing: 2px; text-transform: uppercase; color: rgba(255,255,255,0.5); margin-top: 3px;">We don't design. We influence.</div></div>
            <h1 style="margin: 0; font-size: 22px; font-weight: 800; color: #fff;">${heading}</h1>
            <p style="margin: 6px 0 0; opacity: 0.85; font-size: 13px; color: #fff;">Week ${9 - weekNum} of 8 countdown</p>
        </div>
        <div style="padding: 24px;">
            <p style="font-size: 14px; line-height: 1.7; color: #ccc;">${body}</p>
            <div style="background: rgba(255,255,255,0.05); border-radius: 10px; padding: 16px; margin: 20px 0;">
                <p style="font-size: 11px; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; color: #dc2626; margin: 0 0 10px;">Quick Picks</p>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr><td style="padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.06); color: #fff; font-size: 13px;">Social Media Graphics Kit</td><td style="text-align: right; color: #dc2626; font-weight: 700; font-size: 13px; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.06);">$195</td></tr>
                    <tr><td style="padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.06); color: #fff; font-size: 13px;">Storefront Banner</td><td style="text-align: right; color: #dc2626; font-weight: 700; font-size: 13px; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.06);">$175</td></tr>
                    <tr><td style="padding: 6px 0; color: #fff; font-size: 13px;">Yard Signs (10 pack)</td><td style="text-align: right; color: #dc2626; font-weight: 700; font-size: 13px; padding: 6px 0;">$350</td></tr>
                </table>
            </div>
            <div style="text-align: center; margin: 24px 0;">
                <a href="#" style="display: inline-block; background: #dc2626; color: #fff; padding: 14px 36px; font-size: 14px; font-weight: 700; text-decoration: none; border-radius: 8px;">${cta}</a>
            </div>
            <p style="font-size: 12px; color: #555; text-align: center;">24hr production · $10 overnight shipping · Design included</p>
        </div>
        <div style="padding: 16px 24px; border-top: 1px solid rgba(255,255,255,0.06); text-align: center;">
            <p style="margin: 0; color: #444; font-size: 10px;">New Urban Influence · Detroit, Michigan · (248) 487-8747</p>
        </div>
    </div>`;
}

async function saveHolidayDripTemplate(weekNum) {
    const btn = document.getElementById('hdtSaveBtn');
    btn.textContent = '⏳ Saving...';
    btn.disabled = true;
    try {
        const res = await fetch('/.netlify/functions/holiday-templates', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                week_number: weekNum,
                subject: document.getElementById('hdtSubject').value,
                heading: document.getElementById('hdtHeading').value,
                body: document.getElementById('hdtBody').value,
                cta: document.getElementById('hdtCta').value
            })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Save failed');
        document.querySelector('div[style*="fixed"]')?.remove();
        loadHolidayDripTemplates();
        alert('✅ Holiday template updated!');
    } catch (err) {
        alert('❌ Save failed: ' + err.message);
        btn.textContent = 'Save Changes';
        btn.disabled = false;
    }
}

function quickSendEmail() {
    const templateId = parseInt(document.getElementById('quickSendTemplate').value);
    const clientId = parseInt(document.getElementById('quickSendClient').value);
    if (!templateId || !clientId) {
        alert('Please select both a template and a client');
        return;
    }
    sendTemplateEmail(templateId, clientId);
}

function previewEmail() {
    const templateId = parseInt(document.getElementById('quickSendTemplate').value);
    const clientId = parseInt(document.getElementById('quickSendClient').value);
    const template = emailTemplates.find(t => t.id === templateId);
    const client = clients.find(c => c.id === clientId) || { name: 'John Smith' };

    if (!template) {
        alert('Please select a template');
        return;
    }

    const html = generateEmailHTML(template, { clientName: client.name });
    const win = window.open('', 'Email Preview', 'width=700,height=800');
    win.document.write(html);
    win.document.close();
}

function previewTemplate(templateId) {
    const template = emailTemplates.find(t => t.id === templateId);
    if (!template) return;

    const html = generateEmailHTML(template, { clientName: 'John Smith' });
    const win = window.open('', 'Email Preview', 'width=700,height=800');
    win.document.write(html);
    win.document.close();
}

function showCreateTemplateModal() {
    const modal = document.createElement('div');
    modal.id = 'templateModal';
    modal.innerHTML = `
<div style="position: fixed; inset: 0; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 9999; padding: 20px;">
<div style="background: #242424; border-radius: 16px; width: 100%; max-width: 700px; max-height: 90vh; overflow-y: auto;">
<div style="padding: 24px; border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center;">
<h2 style="margin: 0; font-size: 20px;">Create Email Template</h2>
<button onclick="document.getElementById('templateModal').remove()" style="background: none; border: none; color: #888; font-size: 24px; cursor: pointer;">&times;</button>
</div>
<div class="p-24">
<div class="mb-16">
<label class="admin-field-label">Template Name</label>
<input type="text" id="newTemplateName" placeholder="e.g., Follow Up Email" class="admin-input-dark">
</div>
<div class="mb-16">
<label class="admin-field-label">Subject Line (use {{clientName}} for personalization)</label>
<input type="text" id="newTemplateSubject" placeholder="e.g., Hey {{clientName}}, quick question..." class="admin-input-dark">
</div>
<div class="mb-16">
<label class="admin-field-label">Category</label>
<select id="newTemplateCategory" class="admin-input-dark">
<option value="onboarding">Onboarding</option>
<option value="project">Project Updates</option>
<option value="payment">Payment</option>
<option value="delivery">Delivery</option>
<option value="newsletter">Newsletter</option>
<option value="promo">Promotional</option>
</select>
</div>
<div class="mb-16">
<label class="admin-field-label">Email Body</label>
<textarea id="newTemplateBody" rows="12" placeholder="Hey {{clientName}},

Write your email here...

Use {{clientName}}, {{designerName}}, {{invoiceNumber}}, {{amount}}, {{paymentLink}}, {{portalLink}} for dynamic content." style="width: 100%; padding: 12px; background: #1c1c1c; border: 1px solid #333; color: #fff; border-radius: 8px; font-family: inherit; line-height: 1.6;"></textarea>
</div>
<button onclick="saveNewTemplate()" style="width: 100%; padding: 14px; background: #e63946; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Save Template</button>
</div>
</div>
</div>
    `;
    document.body.appendChild(modal);
}

function saveNewTemplate() {
    const name = document.getElementById('newTemplateName').value.trim();
    const subject = document.getElementById('newTemplateSubject').value.trim();
    const category = document.getElementById('newTemplateCategory').value;
    const body = document.getElementById('newTemplateBody').value.trim();

    if (!name || !subject || !body) {
        alert('Please fill in all fields');
        return;
    }

    emailTemplates.push({
        id: Date.now(),
        name,
        subject,
        category,
        body
    });
    saveEmailTemplates();

    document.getElementById('templateModal').remove();
    loadAdminEmailTemplatesPanel();
    alert('Template saved!');
}

function editTemplate(templateId) {
    const template = emailTemplates.find(t => t.id === templateId);
    if (!template) return;

    const modal = document.createElement('div');
    modal.id = 'templateModal';
    modal.innerHTML = `
<div style="position: fixed; inset: 0; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 9999; padding: 20px;">
<div style="background: #242424; border-radius: 16px; width: 100%; max-width: 700px; max-height: 90vh; overflow-y: auto;">
<div style="padding: 24px; border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center;">
<h2 style="margin: 0; font-size: 20px;">Edit Template: ${template.name}</h2>
<button onclick="document.getElementById('templateModal').remove()" style="background: none; border: none; color: #888; font-size: 24px; cursor: pointer;">&times;</button>
</div>
<div class="p-24">
<div class="mb-16">
<label class="admin-field-label">Template Name</label>
<input type="text" id="editTemplateName" value="${template.name}" class="admin-input-dark">
</div>
<div class="mb-16">
<label class="admin-field-label">Subject Line</label>
<input type="text" id="editTemplateSubject" value="${template.subject}" class="admin-input-dark">
</div>
<div class="mb-16">
<label class="admin-field-label">Category</label>
<select id="editTemplateCategory" class="admin-input-dark">
<option value="onboarding" ${template.category === 'onboarding' ? 'selected' : ''}>Onboarding</option>
<option value="project" ${template.category === 'project' ? 'selected' : ''}>Project Updates</option>
<option value="payment" ${template.category === 'payment' ? 'selected' : ''}>Payment</option>
<option value="delivery" ${template.category === 'delivery' ? 'selected' : ''}>Delivery</option>
<option value="newsletter" ${template.category === 'newsletter' ? 'selected' : ''}>Newsletter</option>
<option value="promo" ${template.category === 'promo' ? 'selected' : ''}>Promotional</option>
</select>
</div>
<div class="mb-16">
<label class="admin-field-label">Email Body</label>
<textarea id="editTemplateBody" rows="12" style="width: 100%; padding: 12px; background: #1c1c1c; border: 1px solid #333; color: #fff; border-radius: 8px; font-family: inherit; line-height: 1.6;">${template.body}</textarea>
</div>
<div class="flex-gap-12">
<button onclick="updateTemplate(${template.id})" style="flex: 1; padding: 14px; background: #e63946; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Save Changes</button>
<button onclick="deleteTemplate(${template.id})" style="padding: 14px 24px; background: #333; color: #ef4444; border: 1px solid #ef4444; border-radius: 8px; cursor: pointer;">Delete</button>
</div>
</div>
</div>
</div>
    `;
    document.body.appendChild(modal);
}

function updateTemplate(templateId) {
    const template = emailTemplates.find(t => t.id === templateId);
    if (!template) return;

    template.name = document.getElementById('editTemplateName').value.trim();
    template.subject = document.getElementById('editTemplateSubject').value.trim();
    template.category = document.getElementById('editTemplateCategory').value;
    template.body = document.getElementById('editTemplateBody').value.trim();

    saveEmailTemplates();
    document.getElementById('templateModal').remove();
    loadAdminEmailTemplatesPanel();
    alert('Template updated!');
}

function deleteTemplate(templateId) {
    if (!confirm('Delete this template?')) return;
    emailTemplates = emailTemplates.filter(t => t.id !== templateId);
    saveEmailTemplates();
    document.getElementById('templateModal').remove();
    loadAdminEmailTemplatesPanel();
}

// Schedule Campaign Modal
function showScheduleCampaignModal() {
    const modal = document.createElement('div');
    modal.id = 'scheduleModal';
    modal.innerHTML = `
<div style="position: fixed; inset: 0; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 9999; padding: 20px;">
<div style="background: #242424; border-radius: 16px; width: 100%; max-width: 500px;">
<div style="padding: 24px; border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center;">
<h2 style="margin: 0; font-size: 20px;">Schedule Campaign</h2>
<button onclick="document.getElementById('scheduleModal').remove()" style="background: none; border: none; color: #888; font-size: 24px; cursor: pointer;">&times;</button>
</div>
<div class="p-24">
<div class="mb-16">
<label class="admin-field-label">Template</label>
<select id="scheduleTemplate" class="admin-input-dark">
                            ${emailTemplates.map(t => `<option value="${t.id}">${t.name}</option>`).join('')}
</select>
</div>
<div class="mb-16">
<label class="admin-field-label">Send To</label>
<select id="scheduleAudience" class="admin-input-dark">
<option value="all">All Clients</option>
<option value="active">Active Clients (with projects)</option>
<option value="leads">Leads Only</option>
</select>
</div>
<div class="mb-16">
<label class="admin-field-label">Send Date & Time</label>
<input type="datetime-local" id="scheduleDateTime" class="admin-input-dark">
</div>
<button onclick="scheduleCampaign()" style="width: 100%; padding: 14px; background: #10b981; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Schedule Campaign</button>
</div>
</div>
</div>
    `;
    document.body.appendChild(modal);
}

function scheduleCampaign() {
    const templateId = parseInt(document.getElementById('scheduleTemplate').value);
    const audience = document.getElementById('scheduleAudience').value;
    const sendAt = document.getElementById('scheduleDateTime').value;

    if (!sendAt) {
        alert('Please select a date and time');
        return;
    }

    scheduledEmails.push({
        id: Date.now(),
        templateId,
        audience,
        sendAt: new Date(sendAt).toISOString(),
        status: 'scheduled'
    });
    saveScheduledEmails();

    document.getElementById('scheduleModal').remove();
    loadAdminEmailTemplatesPanel();
    alert('Campaign scheduled!');
}

function cancelScheduledEmail(id) {
    if (!confirm('Cancel this scheduled campaign?')) return;
    scheduledEmails = scheduledEmails.filter(s => s.id !== id);
    saveScheduledEmails();
    loadAdminEmailTemplatesPanel();
}

// Check for scheduled emails to send (run on page load and every minute)
function checkScheduledEmails() {
    const now = new Date();
    scheduledEmails.forEach(async (scheduled) => {
        if (scheduled.status === 'scheduled' && new Date(scheduled.sendAt) <= now) {
            // Get recipients based on audience
            let recipients = [];
            if (scheduled.audience === 'all') {
                recipients = clients;
            } else if (scheduled.audience === 'active') {
                const activeClientIds = orders.filter(o => o.status === 'in_progress').map(o => o.clientId);
                recipients = clients.filter(c => activeClientIds.includes(c.id));
            } else if (scheduled.audience === 'leads') {
                recipients = leads;
            }

            // Send to each recipient
            for (const recipient of recipients) {
                await sendTemplateEmail(scheduled.templateId, recipient.id);
            }

            scheduled.status = 'sent';
            saveScheduledEmails();
        }
    });
}

// Run scheduled email check every minute
setInterval(checkScheduledEmails, 60000);
checkScheduledEmails(); // Run immediately on load

// Update admin panel loaders to include email templates
const originalShowAdminPanel = showAdminPanel;
showAdminPanel = function(panel) {
    originalShowAdminPanel(panel);
    if (panel === 'emailmarketing') {
        loadAdminEmailTemplatesPanel();
    }
    if (panel === 'subscriptions') {
        loadAdminSubscriptionsPanel();
    }
};

// ==================== SUBSCRIPTION MANAGEMENT PANEL ====================
function loadAdminSubscriptionsPanel() {
    const totalSubscribers = subscriptions.filter(s => s.status === 'active').length;
    const monthlyRevenue = subscriptions.filter(s => s.status === 'active').reduce((sum, s) => sum + s.price, 0);

    const planBreakdown = {};
    subscriptionPlans.forEach(plan => {
        const count = subscriptions.filter(s => s.planId === plan.id && s.status === 'active').length;
        if (count > 0) planBreakdown[plan.id] = { name: plan.name, count };
    });

    let html = `
<div class="p-32">
<div class="flex-between mb-32">
<div>
<h2 style="font-size: 28px; font-weight: 700; color: #fff; margin: 0;">Subscription Management</h2>
<p style="color: #888; margin-top: 8px;">Manage customer subscriptions and billing plans</p>
</div>
<button onclick="showAssignPlanModal(null)" style="background: #e63946; color: #fff; border: none; padding: 12px 24px; border-radius: 12px; cursor: pointer; font-weight: 600; font-size: 14px;">+ Assign Plan</button>
</div>

            <!-- Stats Cards -->
<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 32px;">
<div class="admin-card-dark-sm">
<div style="color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Total Subscribers</div>
<div style="font-size: 36px; font-weight: 700; color: #e63946;">${totalSubscribers}</div>
<div style="color: #666; font-size: 12px; margin-top: 8px;">Active subscriptions</div>
</div>
<div class="admin-card-dark-sm">
<div style="color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Monthly Revenue</div>
<div style="font-size: 36px; font-weight: 700; color: #10b981;">$${monthlyRevenue.toLocaleString()}</div>
<div style="color: #666; font-size: 12px; margin-top: 8px;">Recurring monthly</div>
</div>
<div class="admin-card-dark-sm">
<div style="color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Active Plans</div>
<div style="font-size: 36px; font-weight: 700; color: #3b82f6;">${Object.keys(planBreakdown).length}</div>
<div style="color: #666; font-size: 12px; margin-top: 8px;">Of ${subscriptionPlans.length} plans</div>
</div>
</div>

            <!-- Plan Cards -->
<div class="mb-32">
<h2 style="font-size: 18px; font-weight: 600; color: #fff; margin: 0 0 16px 0;">Plans Overview</h2>
<div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px;">
    `;

    subscriptionPlans.forEach(plan => {
        const count = subscriptions.filter(s => s.planId === plan.id && s.status === 'active').length;
        html += `
<div style="background: #1c1c1c; border: 1px solid #222; border-radius: 12px; padding: 20px; text-align: center;">
<div style="font-size: 28px; font-weight: 700; color: #e63946; margin-bottom: 8px;">$${plan.price}</div>
<div style="font-weight: 600; color: #fff; margin-bottom: 12px; font-size: 14px;">${plan.name}</div>
<div style="font-size: 20px; font-weight: 700; color: #fff; margin-bottom: 12px;">${count}</div>
<div style="color: #666; font-size: 11px; margin-bottom: 16px;">Active subscribers</div>
<button onclick="showAssignPlanModal('${plan.id}')" style="width: 100%; background: #e63946; color: #fff; border: none; padding: 10px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 12px;">Assign Plan</button>
</div>
        `;
    });

    html += `
</div>
</div>

            <!-- Search/Filter -->
<div style="margin-bottom: 20px; display: flex; gap: 12px;">
<input type="text" id="subscriptionSearchInput" placeholder="Search by client name or email..." style="flex: 1; padding: 12px; background: #1c1c1c; border: 1px solid #333; color: #fff; border-radius: 8px; font-size: 14px;">
<select id="subscriptionFilterStatus" onchange="filterSubscriptionTable()" style="padding: 12px; background: #1c1c1c; border: 1px solid #333; color: #fff; border-radius: 8px; cursor: pointer;">
<option value="">All Status</option>
<option value="active">Active</option>
<option value="paused">Paused</option>
<option value="cancelled">Cancelled</option>
</select>
<button onclick="filterSubscriptionTable()" style="background: #e63946; color: #fff; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600;">Search</button>
</div>

            <!-- Active Subscriptions Table -->
<div style="background: #1c1c1c; border: 1px solid #222; border-radius: 12px; overflow: hidden;">
<table id="subscriptionTable" style="width: 100%; border-collapse: collapse;">
<thead>
<tr style="background: #181818; border-bottom: 1px solid #222;">
<th style="padding: 16px; text-align: left; color: #888; font-weight: 600; font-size: 12px; text-transform: uppercase;">Client</th>
<th style="padding: 16px; text-align: left; color: #888; font-weight: 600; font-size: 12px; text-transform: uppercase;">Plan</th>
<th style="padding: 16px; text-align: left; color: #888; font-weight: 600; font-size: 12px; text-transform: uppercase;">Price</th>
<th style="padding: 16px; text-align: left; color: #888; font-weight: 600; font-size: 12px; text-transform: uppercase;">Status</th>
<th style="padding: 16px; text-align: left; color: #888; font-weight: 600; font-size: 12px; text-transform: uppercase;">Start Date</th>
<th style="padding: 16px; text-align: left; color: #888; font-weight: 600; font-size: 12px; text-transform: uppercase;">Next Billing</th>
<th style="padding: 16px; text-align: center; color: #888; font-weight: 600; font-size: 12px; text-transform: uppercase;">Actions</th>
</tr>
</thead>
<tbody id="subscriptionTableBody">
    `;

    subscriptions.forEach(sub => {
        const statusColors = { active: '#10b981', paused: '#f59e0b', cancelled: '#ef4444', pending_payment: '#3b82f6' };
        const statusIcons = { active: '●', paused: '⏸', cancelled: '✕', pending_payment: '💳' };
        const startDate = new Date(sub.startDate).toLocaleDateString();
        const nextBillingDate = new Date(sub.nextBillingDate).toLocaleDateString();

        html += `
<tr style="border-bottom: 1px solid #222; hover: {background: #181818;}">
<td style="padding: 16px; color: #fff;">${sub.clientName}</td>
<td style="padding: 16px; color: rgba(255,255,255,0.7);">${sub.plan}</td>
<td style="padding: 16px; color: #e63946; font-weight: 600;">$${sub.price}/mo</td>
<td class="p-16">
<span style="display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; background: ${statusColors[sub.status]}20; color: ${statusColors[sub.status]}; border-radius: 100px; font-size: 12px; font-weight: 600;">
<span>${statusIcons[sub.status]}</span>
                                    ${sub.status.charAt(0).toUpperCase() + sub.status.slice(1)}
</span>
</td>
<td style="padding: 16px; color: rgba(255,255,255,0.6); font-size: 13px;">${startDate}</td>
<td style="padding: 16px; color: rgba(255,255,255,0.6); font-size: 13px;">${nextBillingDate}</td>
<td style="padding: 16px; text-align: center;">
<div style="display: flex; gap: 8px; justify-content: center;">
                                    ${sub.status === 'active' ? `<button onclick="pauseSubscription(${sub.id})" style="background: #f59e0b; color: #000; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 11px;">Pause</button><button onclick="handleFailedPayment(${sub.id})" style="background: #ef4444; color: #fff; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 11px; margin-left: 4px;">💳 Payment Failed</button>` : sub.status === 'paused' ? `<button onclick="resumeSubscription(${sub.id})" style="background: #10b981; color: #000; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 11px;">Resume</button>` : sub.status === 'pending_payment' ? `<button onclick="resendPaymentLink(${sub.id})" style="background: #3b82f6; color: #fff; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 11px;">📨 Resend Payment Link</button>` : ''}
<button onclick="showChangePlanModal(${sub.id})" style="background: #3b82f6; color: #fff; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 11px;">Change Plan</button>
<button onclick="sendSubscriptionInvoice(${sub.id})" style="background: #10b981; color: #000; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 11px;">Invoice</button>
<button onclick="cancelSubscription(${sub.id})" style="background: #ef4444; color: #fff; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 11px;">Cancel</button>
</div>
</td>
</tr>
        `;
    });

    html += `
</tbody>
</table>
                ${subscriptions.length === 0 ? `<div style="padding: 40px; text-align: center; color: #666;">No subscriptions yet. <a onclick="showAssignPlanModal(null)" style="color: #e63946; cursor: pointer; font-weight: 600;">Create one now</a></div>` : ''}
</div>
</div>
    `;

    document.getElementById('adminSubscriptionsPanel').innerHTML = html;
    document.getElementById('subscriptionSearchInput').addEventListener('input', filterSubscriptionTable);
}

function showAssignPlanModal(planId) {
    const plan = planId ? subscriptionPlans.find(p => p.id === planId) : null;

    let html = `
<div class="modal-overlay" id="assignPlanModal" style="position: fixed; inset: 0; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 10000;">
<div style="background: #1c1c1c; border: 1px solid #333; border-radius: 16px; padding: 32px; max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto;">
<h2 style="font-size: 24px; font-weight: 700; color: #fff; margin: 0 0 24px 0;">Assign Subscription Plan</h2>

<div class="mb-20">
<label style="display: block; color: #fff; font-weight: 600; margin-bottom: 8px;">Select Client</label>
<select id="assignPlanClient" style="width: 100%; padding: 12px; background: #242424; border: 1px solid #333; color: #fff; border-radius: 8px; font-size: 14px;">
<option value="">-- Choose a client --</option>
                        ${clients.map(c => `<option value="${c.id}">${c.name} (${c.email})</option>`).join('')}
</select>
</div>

<div class="mb-20">
<label style="display: block; color: #fff; font-weight: 600; margin-bottom: 8px;">Select Plan</label>
<select id="assignPlanSelect" style="width: 100%; padding: 12px; background: #242424; border: 1px solid #333; color: #fff; border-radius: 8px; font-size: 14px;">
<option value="">-- Choose a plan --</option>
                        ${subscriptionPlans.map(p => `<option value="${p.id}" ${p.id === planId ? 'selected' : ''}>${p.name} - $${p.price}/mo</option>`).join('')}
</select>
</div>

<div id="planPreview" style="background: #181818; border: 1px solid #222; border-radius: 12px; padding: 16px; margin-bottom: 20px; display: none;">
<div style="color: #fff; font-weight: 600; margin-bottom: 12px;" id="planPreviewName"></div>
<div style="color: #888; font-size: 13px; line-height: 1.6;" id="planPreviewFeatures"></div>
</div>

<div class="mb-20">
<label style="display: block; color: #fff; font-weight: 600; margin-bottom: 8px;">Start Date</label>
<input type="date" id="assignPlanStartDate" style="width: 100%; padding: 12px; background: #242424; border: 1px solid #333; color: #fff; border-radius: 8px; font-size: 14px;">
</div>

<div class="mb-20">
<label style="display: block; color: #fff; font-weight: 600; margin-bottom: 8px;">Billing Method</label>
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
<label style="display: flex; align-items: center; gap: 8px; padding: 12px; background: #242424; border: 1px solid #e63946; border-radius: 8px; cursor: pointer;">
<input type="radio" name="billingMethod" value="stripe" checked class="pointer">
<span style="color: #fff; font-size: 14px;">Auto (Stripe)</span>
</label>
<label style="display: flex; align-items: center; gap: 8px; padding: 12px; background: #242424; border: 1px solid #333; border-radius: 8px; cursor: pointer;">
<input type="radio" name="billingMethod" value="manual" class="pointer">
<span style="color: #fff; font-size: 14px;">Manual Invoice</span>
</label>
</div>
</div>

<div class="mb-20">
<label style="display: block; color: #fff; font-weight: 600; margin-bottom: 8px;">Notes (optional)</label>
<textarea id="assignPlanNotes" style="width: 100%; padding: 12px; background: #242424; border: 1px solid #333; color: #fff; border-radius: 8px; font-size: 14px; resize: vertical; min-height: 80px;" placeholder="Any special notes about this subscription..."></textarea>
</div>

<div class="flex-gap-12">
<button onclick="document.getElementById('assignPlanModal').remove()" style="flex: 1; padding: 12px; background: #333; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Cancel</button>
<button onclick="assignSubscription()" style="flex: 1; padding: 12px; background: #e63946; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Assign Plan</button>
</div>
</div>
</div>
    `;

    document.body.appendChild(document.createElement('div')).outerHTML = html;

    // Set today's date as default
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('assignPlanStartDate').value = today;

    // Show plan preview when plan is selected
    document.getElementById('assignPlanSelect').addEventListener('change', function() {
        const selectedPlanId = this.value;
        const selectedPlan = subscriptionPlans.find(p => p.id === selectedPlanId);
        if (selectedPlan) {
            document.getElementById('planPreview').style.display = 'block';
            document.getElementById('planPreviewName').textContent = selectedPlan.name + ' - $' + selectedPlan.price + '/mo';
            document.getElementById('planPreviewFeatures').innerHTML = selectedPlan.features.map(f => '✓ ' + f).join('<br>');
        } else {
            document.getElementById('planPreview').style.display = 'none';
        }
    });
}

async function assignSubscription() {
    const clientId = parseInt(document.getElementById('assignPlanClient').value);
    const planId = document.getElementById('assignPlanSelect').value;
    const startDateStr = document.getElementById('assignPlanStartDate').value;
    const billingMethod = document.querySelector('input[name="billingMethod"]:checked').value;
    const notes = document.getElementById('assignPlanNotes').value;

    if (!clientId || !planId || !startDateStr) {
        alert('Please fill in all required fields');
        return;
    }

    const client = clients.find(c => c.id === clientId);
    const plan = subscriptionPlans.find(p => p.id === planId);

    if (!client || !plan) {
        alert('Invalid client or plan selected');
        return;
    }

    const startDate = new Date(startDateStr);
    const nextBillingDate = new Date(startDate);
    nextBillingDate.setDate(nextBillingDate.getDate() + 30);

    const subscription = {
        id: Date.now(),
        planId: planId,
        clientId: clientId,
        clientName: client.name,
        clientEmail: client.email,
        plan: plan.name,
        price: plan.price,
        billingMethod: billingMethod,
        status: 'active',
        startDate: startDate.toISOString(),
        nextBillingDate: nextBillingDate.toISOString(),
        orderLimit: plan.orderLimit,
        features: plan.features,
        notes: notes,
        history: [{ action: 'created', date: new Date().toISOString(), note: 'Subscription started', user: currentUser?.name || 'Admin' }]
    };

    subscriptions.push(subscription);
    saveSubscriptions();

    logProofActivity(clientId, 'subscription_assigned', `${plan.name} subscription assigned for $${plan.price}/mo`, subscription);

    // Generate Stripe payment link and send to client
    if (client.email && billingMethod !== 'manual') {
        try {
            const stripeResp = await fetch('/.netlify/functions/create-subscription', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    clientEmail: client.email,
                    clientName: client.name,
                    clientId: String(clientId),
                    amount: plan.price,
                    description: plan.name + ' — Monthly Design Subscription',
                    invoiceId: String(subscription.id),
                    billingType: 'monthly',
                    billingCycles: 0
                })
            });
            const stripeData = await stripeResp.json();
            if (stripeData.url) {
                subscription.stripeCheckoutUrl = stripeData.url;
                subscription.stripeSessionId = stripeData.sessionId;
                subscription.status = 'pending_payment';
                saveSubscriptions();

                // Send payment link email
                await fetch('/.netlify/functions/send-email', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        to: client.email,
                        subject: 'Welcome to ' + plan.name + ' — Activate Your Subscription',
                        html: `<div style="font-family:-apple-system,sans-serif;max-width:600px;margin:0 auto;background:#0a0a0a;color:#fff;padding:40px;border-radius:12px;">
<div style="text-align:center;margin-bottom:32px;"><img src="https://newurbaninfluence.com/assets/img/nui-logo-white.png" alt="NUI" style="height:40px;" /></div>
<h2 style="color:#fff;margin-bottom:16px;">Welcome to ${plan.name}! 🎨</h2>
<p style="color:#ccc;line-height:1.7;">Hi ${client.name},</p>
<p style="color:#ccc;line-height:1.7;">Your <strong style="color:#fff;">${plan.name}</strong> design subscription is ready to activate. Click below to set up your payment method and start your first month.</p>
<div style="background:#111;border:1px solid #333;border-radius:10px;padding:20px;margin:24px 0;">
<div style="display:flex;justify-content:space-between;margin-bottom:8px;"><span style="color:#888;">Plan</span><span style="color:#fff;font-weight:600;">${plan.name}</span></div>
<div style="display:flex;justify-content:space-between;margin-bottom:8px;"><span style="color:#888;">Monthly Price</span><span style="color:#e63946;font-weight:700;font-size:18px;">$${plan.price}/mo</span></div>
<div style="display:flex;justify-content:space-between;"><span style="color:#888;">Billing</span><span style="color:#fff;">Monthly recurring</span></div>
</div>
<div style="text-align:center;margin:32px 0;">
<a href="${stripeData.url}" style="display:inline-block;padding:16px 48px;background:#e63946;color:#fff;text-decoration:none;border-radius:8px;font-weight:700;font-size:18px;">Activate Subscription →</a>
</div>
<p style="color:#666;font-size:13px;text-align:center;">This link expires in 24 hours. If you have questions, reply to this email or call (248) 487-8747.</p>
<div style="border-top:1px solid #222;margin-top:32px;padding-top:16px;text-align:center;color:#555;font-size:12px;">New Urban Influence • Detroit, MI</div>
</div>`,
                        clientId: String(clientId)
                    })
                });

                // Also send SMS with payment link
                if (client.phone) {
                    await fetch('/.netlify/functions/send-sms', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            to: client.phone,
                            message: `Hi ${client.name}! Your ${plan.name} design subscription ($${plan.price}/mo) is ready. Activate here: ${stripeData.url} — NUI Team`,
                            clientId: String(clientId)
                        })
                    });
                }

                document.getElementById('assignPlanModal').remove();
                loadAdminSubscriptionsPanel();
                alert(`✅ Subscription created! Stripe payment link sent to ${client.email} and ${client.phone || 'no phone'}.`);
                return;
            }
        } catch (err) {
            console.error('Stripe link error:', err);
        }
    }

    document.getElementById('assignPlanModal').remove();
    loadAdminSubscriptionsPanel();
    alert(`Subscription assigned to ${client.name}. No payment link sent (manual billing or no email).`);
}

function pauseSubscription(subId) {
    const sub = subscriptions.find(s => s.id === subId);
    if (!sub) return;

    if (!confirm(`Pause subscription for ${sub.clientName}? They won't be charged until resumed.`)) return;

    sub.status = 'paused';
    sub.history.push({ action: 'paused', date: new Date().toISOString(), note: 'Subscription paused', user: currentUser?.name || 'Admin' });
    saveSubscriptions();
    loadAdminSubscriptionsPanel();
    alert('Subscription paused');
}

// ── Failed Payment Handler ──
async function handleFailedPayment(subId) {
    const sub = subscriptions.find(s => s.id === subId);
    if (!sub) return;
    const client = clients.find(c => c.id === sub.clientId);
    if (!client) return;

    // Pause the subscription
    sub.status = 'paused';
    sub.pauseReason = 'payment_failed';
    sub.paymentFailedDate = new Date().toISOString();
    sub.history.push({ action: 'paused', date: new Date().toISOString(), note: 'Auto-paused: payment failed', user: 'System' });
    saveSubscriptions();

    const planName = sub.plan || 'Design Subscription';
    const portalUrl = 'https://newurbaninfluence.com/app/#login';

    // Send email notification
    if (client.email) {
        try {
            await fetch('/.netlify/functions/send-email', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    to: client.email,
                    subject: 'Action Required: Your Design Subscription Has Been Paused',
                    html: `
<div style="font-family: -apple-system, sans-serif; max-width: 600px; margin: 0 auto; background: #0a0a0a; color: #fff; padding: 40px; border-radius: 12px;">
<div style="text-align: center; margin-bottom: 32px;">
<img src="https://newurbaninfluence.com/assets/img/nui-logo-white.png" alt="New Urban Influence" style="height: 40px;" />
</div>
<h2 style="color: #ef4444; margin-bottom: 16px;">⚠️ Subscription Paused</h2>
<p style="color: #ccc; line-height: 1.7; font-size: 15px;">Hi ${client.name},</p>
<p style="color: #ccc; line-height: 1.7; font-size: 15px;">We were unable to process your payment for your <strong style="color: #fff;">${planName}</strong> plan. Your subscription has been temporarily paused.</p>
<div style="background: #1a1a1a; border: 1px solid #333; border-radius: 10px; padding: 20px; margin: 24px 0;">
<p style="color: #f59e0b; font-weight: 600; margin: 0 0 8px 0;">What this means:</p>
<p style="color: #999; font-size: 14px; line-height: 1.6; margin: 0;">• All active design orders are <strong style="color:#fff;">on hold</strong> until payment is resolved<br>
• No new orders can be placed<br>
• Per your service agreement, files from completed orders will be retained for 90 days<br>
• After 90 days without payment, all project files may be permanently removed</p>
</div>
<p style="color: #ccc; line-height: 1.7; font-size: 15px;">Please update your payment method as soon as possible to resume your subscription and avoid interruption to your projects.</p>
<div style="text-align: center; margin: 32px 0;">
<a href="${portalUrl}" style="display: inline-block; padding: 14px 40px; background: #e63946; color: #fff; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 16px;">Update Payment Method →</a>
</div>
<p style="color: #666; font-size: 13px;">If you believe this was an error or need assistance, reply to this email or call us at (248) 487-8747.</p>
<div style="border-top: 1px solid #222; margin-top: 32px; padding-top: 16px; text-align: center; color: #555; font-size: 12px;">
New Urban Influence • Detroit, MI • newurbaninfluence.com
</div>
</div>`,
                    clientId: client.id
                })
            });
            console.log('Payment failed email sent to', client.email);
        } catch (err) { console.error('Failed to send payment email:', err); }
    }

    // Send SMS notification
    if (client.phone) {
        try {
            await fetch('/.netlify/functions/send-sms', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    to: client.phone,
                    message: `Hi ${client.name}, your ${planName} subscription at New Urban Influence has been paused due to a payment issue. All active orders are on hold. Please update your payment method at ${portalUrl} or call us at (248) 487-8747 to resolve this. — NUI Team`,
                    clientId: client.id
                })
            });
            console.log('Payment failed SMS sent to', client.phone);
        } catch (err) { console.error('Failed to send payment SMS:', err); }
    }

    loadAdminSubscriptionsPanel();
    alert(`Subscription paused for ${sub.clientName}. Email and SMS notifications sent.`);
}

// ── Resend Stripe Payment Link ──
async function resendPaymentLink(subId) {
    const sub = subscriptions.find(s => s.id === subId);
    if (!sub) return;
    const client = clients.find(c => c.id === sub.clientId);
    if (!client || !client.email) { alert('No email on file for this client.'); return; }
    const plan = subscriptionPlans.find(p => p.id === sub.planId) || { name: sub.plan, price: sub.price };

    try {
        const resp = await fetch('/.netlify/functions/create-subscription', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                clientEmail: client.email,
                clientName: client.name,
                clientId: String(client.id),
                amount: sub.price,
                description: plan.name + ' — Monthly Design Subscription',
                invoiceId: String(sub.id),
                billingType: 'monthly',
                billingCycles: 0
            })
        });
        const data = await resp.json();
        if (!data.url) throw new Error('No checkout URL returned');

        sub.stripeCheckoutUrl = data.url;
        sub.stripeSessionId = data.sessionId;
        saveSubscriptions();

        await fetch('/.netlify/functions/send-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                to: client.email,
                subject: 'Your Payment Link — ' + plan.name + ' Subscription',
                html: `<div style="font-family:-apple-system,sans-serif;max-width:600px;margin:0 auto;background:#0a0a0a;color:#fff;padding:40px;border-radius:12px;">
<h2 style="color:#fff;">Activate Your ${plan.name} Plan</h2>
<p style="color:#ccc;line-height:1.7;">Hi ${client.name}, click below to set up payment for your <strong>$${sub.price}/mo</strong> design subscription.</p>
<div style="text-align:center;margin:32px 0;"><a href="${data.url}" style="display:inline-block;padding:16px 48px;background:#e63946;color:#fff;text-decoration:none;border-radius:8px;font-weight:700;font-size:18px;">Activate Subscription →</a></div>
<p style="color:#666;font-size:13px;text-align:center;">Link expires in 24 hours. Questions? Call (248) 487-8747.</p>
<div style="border-top:1px solid #222;margin-top:32px;padding-top:16px;text-align:center;color:#555;font-size:12px;">New Urban Influence • Detroit, MI</div></div>`,
                clientId: String(client.id)
            })
        });

        if (client.phone) {
            await fetch('/.netlify/functions/send-sms', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    to: client.phone,
                    message: `Hi ${client.name}! Here's your payment link for the ${plan.name} plan ($${sub.price}/mo): ${data.url} — NUI Team`,
                    clientId: String(client.id)
                })
            });
        }

        sub.history.push({ action: 'payment_link_sent', date: new Date().toISOString(), note: 'Stripe payment link resent', user: currentUser?.name || 'Admin' });
        saveSubscriptions();
        loadAdminSubscriptionsPanel();
        alert(`✅ New payment link sent to ${client.email}${client.phone ? ' and ' + client.phone : ''}!`);
    } catch (err) {
        console.error('Resend payment link error:', err);
        alert('Error generating payment link: ' + err.message);
    }
}

function resumeSubscription(subId) {
    const sub = subscriptions.find(s => s.id === subId);
    if (!sub) return;

    sub.status = 'active';
    sub.history.push({ action: 'resumed', date: new Date().toISOString(), note: 'Subscription resumed', user: currentUser?.name || 'Admin' });
    saveSubscriptions();
    loadAdminSubscriptionsPanel();
    alert('Subscription resumed');
}

function cancelSubscription(subId) {
    const sub = subscriptions.find(s => s.id === subId);
    if (!sub) return;

    if (!confirm(`Cancel subscription for ${sub.clientName}? This action cannot be undone.`)) return;

    sub.status = 'cancelled';
    sub.cancelledDate = new Date().toISOString();
    sub.history.push({ action: 'cancelled', date: new Date().toISOString(), note: 'Subscription cancelled', user: currentUser?.name || 'Admin' });
    saveSubscriptions();
    loadAdminSubscriptionsPanel();
    alert('Subscription cancelled');
}

function showChangePlanModal(subId) {
    const sub = subscriptions.find(s => s.id === subId);
    if (!sub) return;

    let html = `
<div class="modal-overlay" id="changePlanModal" style="position: fixed; inset: 0; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 10000;">
<div style="background: #1c1c1c; border: 1px solid #333; border-radius: 16px; padding: 32px; max-width: 600px; width: 90%;">
<h2 style="font-size: 24px; font-weight: 700; color: #fff; margin: 0 0 24px 0;">Change Plan for ${sub.clientName}</h2>

<div style="background: #181818; border: 1px solid #222; border-radius: 12px; padding: 16px; margin-bottom: 20px;">
<div style="font-size: 13px; color: #888; margin-bottom: 4px;">Current Plan</div>
<div style="font-size: 18px; font-weight: 600; color: #fff;">${sub.plan} - $${sub.price}/mo</div>
</div>

<div class="mb-20">
<label style="display: block; color: #fff; font-weight: 600; margin-bottom: 12px;">Select New Plan</label>
<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px;">
    `;

    subscriptionPlans.forEach(plan => {
        const isCurrentPlan = plan.id === sub.planId;
        html += `
<button onclick="changePlan(${subId}, '${plan.id}')" style="padding: 16px; background: ${isCurrentPlan ? '#e63946' : '#1a1a1a'}; border: ${isCurrentPlan ? '2px solid #e63946' : '1px solid #333'}; border-radius: 8px; cursor: ${isCurrentPlan ? 'default' : 'pointer'}; color: #fff; text-align: left; transition: all 0.2s;" ${isCurrentPlan ? 'disabled' : ''}>
<div style="font-weight: 600; margin-bottom: 4px;">${plan.name}</div>
<div style="font-size: 14px; font-weight: 700; color: ${isCurrentPlan ? '#fff' : '#e63946'};">$${plan.price}/mo</div>
                            ${isCurrentPlan ? '<div style="font-size: 11px; color: rgba(255,255,255,0.6); margin-top: 8px;">Current Plan</div>' : ''}
</button>
        `;
    });

    html += `
</div>
</div>

<div class="flex-gap-12">
<button onclick="document.getElementById('changePlanModal').remove()" style="flex: 1; padding: 12px; background: #333; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Cancel</button>
</div>
</div>
</div>
    `;

    document.body.appendChild(document.createElement('div')).outerHTML = html;
}

function changePlan(subId, newPlanId) {
    const sub = subscriptions.find(s => s.id === subId);
    const newPlan = subscriptionPlans.find(p => p.id === newPlanId);

    if (!sub || !newPlan || newPlan.id === sub.planId) {
        return;
    }

    const oldPlan = sub.plan;
    const oldPrice = sub.price;

    sub.planId = newPlanId;
    sub.plan = newPlan.name;
    sub.price = newPlan.price;
    sub.orderLimit = newPlan.orderLimit;
    sub.features = newPlan.features;
    sub.history.push({
        action: 'plan_changed',
        date: new Date().toISOString(),
        note: `Changed from ${oldPlan} ($${oldPrice}/mo) to ${newPlan.name} ($${newPlan.price}/mo)`,
        user: currentUser?.name || 'Admin'
    });

    saveSubscriptions();
    document.getElementById('changePlanModal').remove();
    loadAdminSubscriptionsPanel();
    alert(`Plan changed! ${sub.clientName} is now on the ${newPlan.name} plan ($${newPlan.price}/mo).`);
}

function sendSubscriptionInvoice(subId) {
    const sub = subscriptions.find(s => s.id === subId);
    if (!sub) return;

    const invoice = {
        id: Date.now() + Math.random(),
        invoiceNumber: 'SUB-INV-' + sub.id + '-' + new Date().getTime(),
        clientId: sub.clientId,
        clientName: sub.clientName,
        clientEmail: sub.clientEmail,
        subscriptionId: sub.id,
        projectName: sub.plan + ' Subscription - Monthly',
        lineItems: [{
            description: `${sub.plan} - Monthly subscription (${new Date(sub.nextBillingDate).toLocaleDateString()})`,
            amount: sub.price
        }],
        subtotal: sub.price,
        total: sub.price,
        dueDate: new Date(sub.nextBillingDate).toISOString().split('T')[0],
        notes: `Billing Method: ${sub.billingMethod === 'stripe' ? 'Automatic (Stripe)' : 'Manual Invoice'}`,
        status: 'pending',
        termsAccepted: false,
        createdAt: new Date().toISOString()
    };

    invoices.push(invoice);
    saveInvoices();

    // Send invoice to client
    if (sub.clientEmail) {
        try {
            sendInvoiceToClient(invoice);
        } catch (e) {
            console.log('Email notification not available');
        }
    }

    alert(`Invoice sent to ${sub.clientName}`);
    loadAdminSubscriptionsPanel();
}

function filterSubscriptionTable(query) {
    const searchInput = document.getElementById('subscriptionSearchInput');
    const statusFilter = document.getElementById('subscriptionFilterStatus');
    const searchQuery = (query || searchInput.value).toLowerCase();
    const statusValue = statusFilter.value;

    const rows = document.querySelectorAll('#subscriptionTableBody tr');
    rows.forEach(row => {
        const clientName = row.cells[0].textContent.toLowerCase();
        const statusText = row.cells[3].textContent.toLowerCase();

        const matchesSearch = clientName.includes(searchQuery);
        const matchesStatus = statusValue === '' || statusText.includes(statusValue);

        row.style.display = matchesSearch && matchesStatus ? '' : 'none';
    });
}
