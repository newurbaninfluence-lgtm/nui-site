// ==================== CLIENT PORTAL (PORTFOLIO-STYLE BRAND GUIDE) ====================

// Asset gallery builder — renders any category of assets as a responsive grid with lightbox
function buildAssetGallery(assets, categoryLabel, accentColor, columns) {
    if (!assets || !assets.length) return '';
    const imageAssets = assets.filter(a => a.type === 'image' || a.data?.startsWith('data:image') || a.data?.match?.(/\.(png|jpg|jpeg|gif|svg|webp)/i));
    const videoAssets = assets.filter(a => a.type === 'video' || a.data?.startsWith('data:video'));
    const fileAssets = assets.filter(a => !imageAssets.includes(a) && !videoAssets.includes(a));
    const allVisual = [...imageAssets, ...videoAssets, ...fileAssets];
    if (!allVisual.length) return '';

    const cols = columns || (allVisual.length === 1 ? 1 : allVisual.length === 2 ? 2 : 3);
    const items = allVisual.map((a, i) => {
        const isImg = imageAssets.includes(a);
        const isVid = videoAssets.includes(a);
        const safeName = (a.name || '').replace(/"/g, '&quot;');
        if (isImg) {
            return '<div class="bg-asset-card" data-lb-src="' + (a.data || '') + '" data-lb-name="' + safeName + '" onclick="openPortalLightbox(this.dataset.lbSrc, this.dataset.lbName)">' +
                '<img loading="lazy" src="' + a.data + '" alt="' + safeName + '" style="width:100%;height:100%;object-fit:contain;padding:8px;">' +
                '<div class="bg-asset-label">' + safeName + '</div></div>';
        } else if (isVid) {
            return '<div class="bg-asset-card"><video src="' + a.data + '" controls style="width:100%;height:100%;object-fit:contain;"></video>' +
                '<div class="bg-asset-label">' + safeName + '</div></div>';
        } else {
            return '<div class="bg-asset-card" style="display:flex;align-items:center;justify-content:center;">' +
                '<div style="text-align:center;"><div style="font-size:32px;margin-bottom:8px;">📎</div>' +
                '<div style="color:rgba(255,255,255,0.6);font-size:13px;">' + safeName + '</div></div></div>';
        }
    }).join('');

    return '<div class="brand-section"><div class="brand-section-title">' + categoryLabel + '</div>' +
        '<div style="display:grid;grid-template-columns:repeat(' + cols + ',1fr);gap:16px;">' + items + '</div></div>';
}

// Lightbox for full-size image preview
function openPortalLightbox(src, title) {
    if (!src) return;
    const existing = document.getElementById('portalLightbox');
    if (existing) existing.remove();
    const lb = document.createElement('div');
    lb.id = 'portalLightbox';
    lb.style.cssText = 'position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,0.92);display:flex;align-items:center;justify-content:center;flex-direction:column;cursor:zoom-out;animation:fadeIn 0.2s ease;';
    lb.onclick = () => lb.remove();
    lb.innerHTML = `
<img src="${src}" alt="${title || ''}" style="max-width:90vw;max-height:80vh;object-fit:contain;border-radius:8px;box-shadow:0 8px 40px rgba(0,0,0,0.5);">
${title ? '<div style="color:rgba(255,255,255,0.7);font-size:14px;margin-top:16px;text-align:center;">' + title + '</div>' : ''}
<div style="position:absolute;top:24px;right:32px;font-size:32px;color:#fff;cursor:pointer;opacity:0.7;">✕</div>`;
    document.body.appendChild(lb);
}

function showClientPortal(client) {
    // Ensure colors array exists (may be in brandAssets)
    if (!client.colors || !client.colors.length) {
        client.colors = client.brandAssets?.colors || ['#e11d48', '#1a1a1a', '#ffffff'];
    }
    document.getElementById('clientPortalName').textContent = client.name + ' Brand Portal';
    const clientOrders = orders.filter(o => o.clientId === client.id);
    const deliveredOrders = clientOrders.filter(o => o.status === 'delivered');
    const activeOrders = clientOrders.filter(o => o.status !== 'delivered');
    // All projects for this client (supports both clientId and client_id field names)
    const clientProjects = (typeof projects !== 'undefined' ? projects : []).filter(p => p.clientId == client.id || p.client_id == client.id);
    // Standalone invoices: not tied to any order row
    const clientStandaloneInvoices = (typeof invoices !== 'undefined' ? invoices : []).filter(i => i.clientId == client.id && !i.orderId);
    // All proofs for this client
    const clientAllProofs = (typeof proofs !== 'undefined' ? proofs : []).filter(pr => pr.clientId == client.id);
    const logos = client.assets?.logos || [];
    const videos = client.assets?.video || [];
    const mockups = client.assets?.mockups || [];
    const social = client.assets?.social || [];
    const banners = client.assets?.banner || [];
    const allAssets = Object.values(client.assets || {}).flat();

    // Get brand guide proof status
    const brandGuide = client.brandGuide || { status: 'draft', proofComments: [] };
    const isPaid = checkClientPaymentStatus(client.id);

    function isLight(c) { const hex = c.replace('#',''); const r = parseInt(hex.substr(0,2),16); const g = parseInt(hex.substr(2,2),16); const b = parseInt(hex.substr(4,2),16); return (r*299+g*587+b*114)/1000 > 128; }

    document.getElementById('clientPortalContent').innerHTML = `
        <!-- Back Navigation Bar -->
<div class="portal-nav-bar" style="background: rgba(0,0,0,0.95); padding: 12px 24px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 100;">
<button onclick="goBackFromPortal()" class="portal-back-btn" style="display: flex; align-items: center; gap: 8px; background: none; border: none; color: #fff; cursor: pointer; font-size: 16px; padding: 8px 16px; border-radius: 8px; transition: background 0.2s;">
<span class="fs-20">←</span> Back
</button>
<span class="text-muted fs-14">${client.name} Portal</span>
            ${currentUser?.type === 'admin' ? '<button onclick="backToAdmin()" style="background: var(--accent); color: #000; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-weight: 600;">Admin Dashboard</button>' : '<div></div>'}
</div>

<!-- CLIENT PORTAL MAIN TABS -->
<div style="background: #111; border-bottom: 1px solid #222; padding: 0 24px; display: flex; gap: 0; overflow-x: auto;">
<button onclick="switchPortalSection('dashboard', ${client.id})" class="portal-main-tab active" data-tab="dashboard" style="padding: 14px 24px; background: none; border: none; border-bottom: 2px solid #e11d48; color: #fff; font-weight: 600; font-size: 14px; cursor: pointer; white-space: nowrap; font-family: inherit;">📊 Dashboard</button>
<button onclick="switchPortalSection('brand', ${client.id})" class="portal-main-tab" data-tab="brand" style="padding: 14px 24px; background: none; border: none; border-bottom: 2px solid transparent; color: #888; font-weight: 600; font-size: 14px; cursor: pointer; white-space: nowrap; font-family: inherit;">🎨 Brand Portal</button>
<button onclick="switchPortalSection('orders', ${client.id})" class="portal-main-tab" data-tab="orders" style="padding: 14px 24px; background: none; border: none; border-bottom: 2px solid transparent; color: #888; font-weight: 600; font-size: 14px; cursor: pointer; white-space: nowrap; font-family: inherit;">📦 Orders & Invoices</button>
<button onclick="switchPortalSection('projects', ${client.id})" class="portal-main-tab" data-tab="projects" style="padding: 14px 24px; background: none; border: none; border-bottom: 2px solid transparent; color: #888; font-weight: 600; font-size: 14px; cursor: pointer; white-space: nowrap; font-family: inherit;">📂 My Projects${clientProjects.length > 0 ? '<span style="background:#3b82f6;color:#fff;border-radius:100px;padding:2px 7px;font-size:11px;margin-left:6px;">' + clientProjects.length + '</span>' : ''}</button>
<button onclick="switchPortalSection('info', ${client.id})" class="portal-main-tab" data-tab="info" style="padding: 14px 24px; background: none; border: none; border-bottom: 2px solid transparent; color: #888; font-weight: 600; font-size: 14px; cursor: pointer; white-space: nowrap; font-family: inherit;">👤 My Info</button>
<button onclick="switchPortalSection('proofs', ${client.id})" class="portal-main-tab" data-tab="proofs" style="padding: 14px 24px; background: none; border: none; border-bottom: 2px solid transparent; color: #888; font-weight: 600; font-size: 14px; cursor: pointer; white-space: nowrap; font-family: inherit;">✅ Proofs ${proofs.filter(pr => pr.clientId == client.id && pr.sentToClient && pr.status === 'pending').length > 0 ? '<span style="background:#e11d48;color:#fff;border-radius:100px;padding:2px 8px;font-size:11px;margin-left:4px;">' + proofs.filter(pr => pr.clientId == client.id && pr.sentToClient && pr.status === 'pending').length + '</span>' : ''}</button>
<button onclick="switchPortalSection('questionnaire', ${client.id})" class="portal-main-tab" data-tab="questionnaire" style="padding: 14px 24px; background: none; border: none; border-bottom: 2px solid transparent; color: #888; font-weight: 600; font-size: 14px; cursor: pointer; white-space: nowrap; font-family: inherit;">📋 Questionnaire</button>
<button onclick="switchPortalSection('faq', ${client.id})" class="portal-main-tab" data-tab="faq" style="padding: 14px 24px; background: none; border: none; border-bottom: 2px solid transparent; color: #888; font-weight: 600; font-size: 14px; cursor: pointer; white-space: nowrap; font-family: inherit;">❓ FAQ</button>
</div>

<!-- DASHBOARD SECTION -->
<div id="portalSection-dashboard" class="portal-section p-32">
<h2 style="font-size: 24px; font-weight: 700; margin-bottom: 24px;">Welcome back, ${client.contact || client.name}!</h2>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 32px;">
<div class="admin-card-dark-sm">
<div style="font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Active Orders</div>
<div style="font-size: 28px; font-weight: 700; color: #3b82f6;">${activeOrders.length}</div>
</div>
<div class="admin-card-dark-sm">
<div style="font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Total Projects</div>
<div style="font-size: 28px; font-weight: 700; color: #a855f7;">${clientProjects.length}</div>
</div>
<div class="admin-card-dark-sm">
<div style="font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Completed</div>
<div style="font-size: 28px; font-weight: 700; color: #10b981;">${deliveredOrders.length + clientProjects.filter(p => p.stage === 'Complete' || p.stage === 'Delivery' || p.status === 'completed').length}</div>
</div>
<div class="admin-card-dark-sm">
<div style="font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Proofs Pending</div>
<div style="font-size: 28px; font-weight: 700; color: ${clientAllProofs.filter(pr => pr.sentToClient && pr.status === 'pending').length > 0 ? '#f59e0b' : '#10b981'};">${clientAllProofs.filter(pr => pr.sentToClient && pr.status === 'pending').length > 0 ? '⏳ ' + clientAllProofs.filter(pr => pr.sentToClient && pr.status === 'pending').length : '✓ Clear'}</div>
</div>
</div>
${(() => {
    const pendingProofs = proofs.filter(pr => pr.clientId == client.id && pr.sentToClient && pr.status === 'pending');
    return pendingProofs.length > 0 ? '<div style="background: #f59e0b15; border: 1px solid #f59e0b40; border-radius: 12px; padding: 20px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;"><div><span class="fs-20">⏳</span> <strong style="color: #f59e0b;">' + pendingProofs.length + ' proof' + (pendingProofs.length > 1 ? 's' : '') + ' waiting for your review</strong><div style="color: #888; font-size: 13px; margin-top: 4px;">' + pendingProofs.map(p => p.title || p.name || 'Proof').join(', ') + '</div></div><button onclick="switchPortalSection(\'proofs\', ' + client.id + ')" style="padding: 12px 24px; background: #f59e0b; color: #000; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit;">Review Now →</button></div>' : '';
})()}

<!-- Quick Actions: Contact Designer & Book a Call -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 32px;">
<button onclick="openClientMessageDesigner(${client.id})" style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 24px; cursor: pointer; text-align: left; font-family: inherit; transition: border-color 0.2s;" onmouseover="this.style.borderColor='#e11d48'" onmouseout="this.style.borderColor='#222'">
<div class="fs-24 mb-8">💬</div>
<div style="font-size: 16px; font-weight: 600; color: #fff;">Contact Your Designer</div>
<div style="font-size: 13px; color: #888; margin-top: 4px;">Send a message about your project</div>
</button>
<button onclick="openBookCallModal()" style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 24px; cursor: pointer; text-align: left; font-family: inherit; transition: border-color 0.2s;" onmouseover="this.style.borderColor='#e11d48'" onmouseout="this.style.borderColor='#222'">
<div class="fs-24 mb-8">📞</div>
<div style="font-size: 16px; font-weight: 600; color: #fff;">Book a Call</div>
<div style="font-size: 13px; color: #888; margin-top: 4px;">Mon–Thu 1:00–4:00 PM EST</div>
</button>
</div>

<!-- Flexible Payment / Financing Banner -->
<div style="background: linear-gradient(135deg, rgba(168,85,247,0.15), rgba(59,130,246,0.1)); border: 1px solid rgba(168,85,247,0.3); border-radius: 16px; padding: 28px 32px; margin-bottom: 32px; position: relative; overflow: hidden;">
<div style="position:absolute;top:-20px;right:-10px;font-size:80px;opacity:0.06;">💳</div>
<div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
<div style="flex:1;min-width:240px;">
<div style="font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 6px;">Pay Your Way — 0% Financing Available</div>
<p style="font-size: 14px; color: rgba(255,255,255,0.65); margin: 0; line-height: 1.5;">Big project? No problem. Split your investment into easy payments with <strong style="color:#a855f7;">Afterpay</strong> or <strong style="color:#3b82f6;">Klarna</strong> — 0% interest, instant approval at checkout. Pay in 4, or choose a flexible monthly plan that works for you.</p>
<div style="display: flex; gap: 20px; margin-top: 14px; align-items: center;">
<div style="display:flex;align-items:center;gap:8px;"><div style="width:32px;height:32px;background:#000;border-radius:6px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;color:#b6f09c;letter-spacing:-0.5px;">A</div><span style="font-size:12px;color:rgba(255,255,255,0.5);">Pay in 4</span></div>
<div style="display:flex;align-items:center;gap:8px;"><div style="width:32px;height:32px;background:#ffb3c7;border-radius:6px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;color:#000;">K</div><span style="font-size:12px;color:rgba(255,255,255,0.5);">Flexible plans</span></div>
<div style="font-size:11px;color:rgba(255,255,255,0.35);border-left:1px solid rgba(255,255,255,0.1);padding-left:16px;">No credit check for most purchases</div>
</div>
</div>
</div>
</div>

${activeOrders.length > 0 ? '<h3 style="font-size: 16px; font-weight: 600; margin-bottom: 16px; color: #fff;">Active Projects</h3>' + activeOrders.map(o => '<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 20px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center;"><div><div class="text-bold-white">' + o.projectName + '</div><div style="font-size: 13px; color: #888; margin-top: 4px;">' + (o.packageName || '') + ' • ' + (o.status || 'pending') + '</div></div><div class="text-muted-sm">' + (o.dueDate ? 'Due: ' + new Date(o.dueDate).toLocaleDateString() : '') + '</div></div>').join('') : '<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 32px; text-align: center; color: #888;">No active orders yet. Your projects will appear here once created.</div>'}
</div>

<!-- ORDERS & INVOICES SECTION -->
<div id="portalSection-orders" class="portal-section" style="padding: 32px; display: none;">
<h2 style="font-size: 24px; font-weight: 700; margin-bottom: 24px;">Orders & Invoices</h2>
${clientOrders.length > 0 ? clientOrders.map(o => {
    const inv = invoices.find(i => i.orderId === o.id || i.orderId == o.id);
    const statusColors = { pending: '#f59e0b', 'in-progress': '#3b82f6', review: '#8b5cf6', delivered: '#10b981', cancelled: '#ef4444' };
    return '<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 24px; margin-bottom: 16px;"><div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;"><div><h3 style="font-size: 18px; font-weight: 600; color: #fff; margin-bottom: 6px;">' + (o.projectName || o.packageName || 'Order #' + o.id) + '</h3><div class="text-muted-sm">' + (o.packageName || 'Custom') + ' • Created ' + new Date(o.createdAt).toLocaleDateString() + '</div></div><div style="display: flex; gap: 12px; align-items: center;"><span style="display: inline-block; padding: 6px 14px; border-radius: 100px; font-size: 12px; font-weight: 600; background: ' + (statusColors[o.status] || '#888') + '20; color: ' + (statusColors[o.status] || '#888') + ';">' + (o.status || 'pending') + '</span>' + (o.total || o.estimate ? '<span style="font-size: 18px; font-weight: 700; color: #e11d48;">$' + (o.total || o.estimate || 0).toLocaleString() + '</span>' : '') + '</div></div>' + (o.turnaround ? '<div style="margin-top: 12px; font-size: 13px; color: #888;">⏱ Turnaround: ' + o.turnaround + (o.dueDate ? ' • Due: ' + new Date(o.dueDate).toLocaleDateString() : '') + '</div>' : '') + (inv ? '<div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #222; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;"><span class="text-muted-sm">Invoice #' + (inv.invoiceNumber || inv.id) + '</span><div style="display:flex;align-items:center;gap:8px;"><span style="font-size: 13px; font-weight: 600; color: ' + (inv.status === 'paid' ? '#10b981' : '#f59e0b') + ';">' + (inv.status === 'paid' ? '✅ Paid in Full' : '⏳ Unpaid — $' + (inv.total || inv.amount || 0).toLocaleString()) + '</span>' + (inv.status !== 'paid' ? '<button onclick="portalPayInvoice(' + inv.id + ')" style="padding:8px 20px;background:#e11d48;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:600;font-size:13px;font-family:inherit;">Pay Now →</button>' : '') + '</div></div>' : '') + '</div>';
}).join('') : ''}
${clientOrders.length === 0 && clientStandaloneInvoices.length === 0 ? '<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 48px; text-align: center;"><div style="font-size: 48px; margin-bottom: 16px;">📦</div><div style="color: #888; font-size: 16px;">No orders yet</div><div style="color: #666; font-size: 14px; margin-top: 8px;">Your orders and invoices will appear here</div></div>' : ''}
${clientStandaloneInvoices.length > 0 ? '<div style="margin-top: 24px;"><h3 style="font-size: 16px; font-weight: 600; color: #888; margin-bottom: 16px; text-transform: uppercase; letter-spacing: 1px; font-size: 12px;">Additional Invoices</h3>' + clientStandaloneInvoices.map(inv => '<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 20px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;"><div><div style="font-weight: 600; color: #fff; font-size: 16px;">' + (inv.description || inv.projectName || 'Invoice') + '</div><div style="font-size: 13px; color: #888; margin-top: 4px;">Invoice #' + (inv.invoiceNumber || inv.id) + ' • ' + new Date(inv.createdAt).toLocaleDateString() + '</div></div><div style="display:flex;align-items:center;gap:12px;"><span style="font-size: 16px; font-weight: 700; color: #e11d48;">$' + (inv.total || inv.amount || 0).toLocaleString() + '</span><span style="padding: 5px 12px; border-radius: 100px; font-size: 12px; font-weight: 600; background: ' + (inv.status === 'paid' ? '#10b98120' : '#f59e0b20') + '; color: ' + (inv.status === 'paid' ? '#10b981' : '#f59e0b') + ';">' + (inv.status === 'paid' ? '✅ Paid' : '⏳ Unpaid') + '</span>' + (inv.status !== 'paid' ? '<button onclick="portalPayInvoice(' + inv.id + ')" style="padding:8px 20px;background:#e11d48;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:600;font-size:13px;font-family:inherit;">Pay Now →</button>' : '') + '</div></div>').join('') + '</div>' : ''}
</div>

<!-- PROJECTS SECTION -->
<div id="portalSection-projects" class="portal-section" style="padding: 32px; display: none;">
<h2 style="font-size: 24px; font-weight: 700; margin-bottom: 8px;">My Projects</h2>
<p class="text-muted mb-24">Every brand guide, website, logo, and one-off job — with proofs, feedback, and links.</p>
${(() => {
    if (clientProjects.length === 0) return '<div style="background:#111;border:1px solid #222;border-radius:12px;padding:48px;text-align:center;"><div style="font-size:48px;margin-bottom:16px;">📂</div><div style="color:#888;font-size:16px;">No projects yet</div><div style="color:#666;font-size:14px;margin-top:8px;">Projects will appear here once your designer sets them up.</div></div>';
    const typeIcons = { 'brand-guide':'🎨', 'brandguide':'🎨', website:'🌐', logo:'✏️', social:'📱', print:'🖨️', video:'🎬', 'one-off':'⚡' };
    const stageClr = { Delivery:'#10b981', Complete:'#10b981', complete:'#10b981', completed:'#10b981', Review:'#a855f7', Design:'#3b82f6', Discovery:'#f59e0b' };
    return clientProjects.map(function(proj) {
        var projProofs = clientAllProofs.filter(function(pr){ return pr.projectId == proj.id || pr.project_id == proj.id; });
        var isWeb = proj.type === 'website';
        var isBG  = proj.type === 'brand-guide' || proj.type === 'brandguide';
        var sClr  = stageClr[proj.stage] || stageClr[proj.status] || '#888';
        var icon  = typeIcons[proj.type] || '📁';
        var webUrl = proj.websiteUrl || (isWeb ? client.websiteUrl : null);
        var displayDate = proj.completedAt ? 'Completed ' + new Date(proj.completedAt).toLocaleDateString() : proj.createdAt ? new Date(proj.createdAt).toLocaleDateString() : '';
        var typeName = (proj.type || 'Project').replace(/-/g,' ').replace(/\b\w/g, function(l){ return l.toUpperCase(); });
        var pendingProofCount = projProofs.filter(function(pr){ return pr.status === 'pending' && pr.sentToClient; }).length;
        var html = '<div style="background:#111;border:1px solid ' + (pendingProofCount > 0 ? '#f59e0b' : '#222') + ';border-radius:16px;padding:24px;margin-bottom:20px;">';
        // Header
        html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:16px;">';
        html += '<div><div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;"><span style="font-size:22px;">' + icon + '</span>';
        html += '<h3 style="font-size:18px;font-weight:700;color:#fff;margin:0;">' + (proj.name || 'Untitled Project') + '</h3></div>';
        html += '<div style="font-size:13px;color:#888;">' + typeName + (displayDate ? ' • ' + displayDate : '') + (proj.notes ? '<br><span style="color:rgba(255,255,255,0.5);">' + proj.notes + '</span>' : '') + '</div></div>';
        html += '<span style="padding:6px 16px;border-radius:100px;font-size:12px;font-weight:600;background:' + sClr + '20;color:' + sClr + ';">' + (proj.stage || proj.status || 'Complete') + '</span>';
        html += '</div>';
        // Pending proof alert
        if (pendingProofCount > 0) {
            html += '<div style="background:#f59e0b15;border:1px solid #f59e0b40;border-radius:8px;padding:14px 16px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;"><span style="color:#f59e0b;font-weight:600;">⏳ ' + pendingProofCount + ' proof' + (pendingProofCount > 1 ? 's' : '') + ' waiting for your review</span><button onclick="switchPortalSection(\'proofs\',' + client.id + ')" style="padding:8px 16px;background:#f59e0b;color:#000;border:none;border-radius:6px;cursor:pointer;font-weight:600;font-size:13px;font-family:inherit;">Review Now →</button></div>';
        }
        // Website card
        if (webUrl) {
            html += '<div style="background:#0d1117;border:1px solid #1e3a5f;border-radius:10px;padding:16px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">';
            html += '<div><div style="font-size:11px;color:#888;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Live Website</div>';
            html += '<a href="' + webUrl + '" target="_blank" style="color:#3b82f6;font-weight:600;font-size:15px;">' + webUrl.replace('https://','').replace('http://','') + '</a></div>';
            html += '<div style="display:flex;gap:8px;">';
            html += '<a href="' + webUrl + '" target="_blank" style="padding:10px 20px;background:#3b82f6;color:#fff;border-radius:8px;text-decoration:none;font-weight:600;font-size:13px;">Visit Site →</a>';
            html += '<button onclick="openProjectFeedback(' + proj.id + ',' + client.id + ')" style="padding:10px 20px;background:transparent;border:1px solid #333;color:#aaa;border-radius:8px;cursor:pointer;font-weight:600;font-size:13px;font-family:inherit;">💬 Leave Feedback</button>';
            html += '</div></div>';
        }
        // Proofs linked to this project
        if (projProofs.length > 0) {
            html += '<div><div style="font-size:11px;color:#888;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;">Design Proofs (' + projProofs.length + ')</div>';
            html += projProofs.map(function(pr) {
                var pc = pr.status === 'approved' ? '#10b981' : pr.status === 'pending' ? '#f59e0b' : pr.status === 'revision' ? '#ef4444' : '#888';
                var pl = pr.status === 'approved' ? '✅ Approved' : pr.status === 'pending' ? '⏳ Pending Review' : pr.status === 'revision' ? '🔄 Revising' : (pr.status || 'Draft');
                var phtml = '<div style="background:#0a0a0a;border:1px solid ' + pc + '30;border-radius:8px;padding:14px 16px;margin-bottom:8px;">';
                phtml += '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">';
                phtml += '<div><div style="font-weight:600;color:#fff;font-size:14px;">' + (pr.title || pr.name || 'Design Proof') + '</div>';
                phtml += '<div style="font-size:12px;color:#888;margin-top:2px;">' + (pr.proofTypeName || pr.category || pr.type || 'Proof') + ' • v' + (pr.version || 1) + (pr.createdAt ? ' • ' + new Date(pr.createdAt).toLocaleDateString() : '') + '</div></div>';
                phtml += '<span style="padding:5px 12px;border-radius:100px;font-size:11px;font-weight:600;background:' + pc + '20;color:' + pc + ';">' + pl + '</span>';
                phtml += '</div>';
                if (pr.image || pr.fileData) {
                    phtml += '<div style="margin-top:12px;border-radius:6px;overflow:hidden;max-height:200px;"><img src="' + (pr.image || pr.fileData) + '" style="width:100%;object-fit:contain;max-height:200px;" alt="Proof"></div>';
                }
                if (pr.notes) {
                    phtml += '<div style="margin-top:10px;padding:10px 12px;background:#111;border-radius:6px;font-size:13px;color:rgba(255,255,255,0.6);">' + pr.notes + '</div>';
                }
                if (pr.status === 'pending' && pr.sentToClient) {
                    phtml += '<div style="display:flex;gap:10px;margin-top:12px;">';
                    phtml += '<button onclick="clientRequestProofRevision(' + pr.id + ',' + client.id + ')" style="flex:1;padding:12px;background:transparent;border:1px solid #ef4444;color:#ef4444;border-radius:8px;cursor:pointer;font-weight:600;font-family:inherit;font-size:13px;">🔄 Request Changes</button>';
                    phtml += '<button onclick="clientApproveProof(' + pr.id + ',' + client.id + ')" style="flex:1;padding:12px;background:#10b981;border:none;color:#fff;border-radius:8px;cursor:pointer;font-weight:600;font-family:inherit;font-size:13px;">✅ Approve</button>';
                    phtml += '</div>';
                }
                phtml += '</div>';
                return phtml;
            }).join('');
            html += '</div>';
        }
        html += '</div>';
        return html;
    }).join('');
})()}
</div>

<!-- MY INFO SECTION -->
<div id="portalSection-info" class="portal-section" style="padding: 32px; display: none;">
<h2 style="font-size: 24px; font-weight: 700; margin-bottom: 24px;">My Information</h2>
<div style="max-width: 600px;">
<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 24px; margin-bottom: 16px;">
<div class="admin-label-xs">Business Name</div>
<div style="font-size: 16px; color: #fff; font-weight: 600;">${client.name}</div>
</div>
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
<div class="admin-card-dark-sm">
<div class="admin-label-xs">Contact</div>
<div class="fs-16 text-white">${client.contact || '—'}</div>
</div>
<div class="admin-card-dark-sm">
<div class="admin-label-xs">Email</div>
<div class="fs-16 text-white">${client.email}</div>
</div>
<div class="admin-card-dark-sm">
<div class="admin-label-xs">Phone</div>
<div class="fs-16 text-white">${client.phone || '—'}</div>
</div>
<div class="admin-card-dark-sm">
<div class="admin-label-xs">Industry</div>
<div class="fs-16 text-white">${client.industry || '—'}</div>
</div>
<div class="admin-card-dark-sm">
<div class="admin-label-xs">Website</div>
<div class="fs-16 text-white">${client.website ? '<a href="' + client.website + '" target="_blank" style="color: #e11d48;">' + client.website + '</a>' : '—'}</div>
</div>
<div class="admin-card-dark-sm">
<div class="admin-label-xs">Service</div>
<div class="fs-16 text-white">${client.servicePackageName || '—'}</div>
</div>
</div>
<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 24px; margin-top: 16px;">
<div class="admin-label-xs">Address</div>
<div class="fs-16 text-white">${client.address || '—'}</div>
</div>
<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 24px; margin-top: 16px;">
<div class="admin-label-xs">Member Since</div>
<div class="fs-16 text-white">${client.createdAt ? new Date(client.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : '—'}</div>
</div>
</div>
</div>

<!-- QUESTIONNAIRE SECTION -->
<div id="portalSection-questionnaire" class="portal-section" style="padding: 32px; display: none;">
<h2 style="font-size: 24px; font-weight: 700; margin-bottom: 8px;">Service Questionnaire</h2>
<p class="text-muted mb-24">Help us understand your brand vision so we can deliver the best results.</p>
<div style="max-width: 600px;">
<form onsubmit="submitClientQuestionnaire(event, ${client.id})">
<div class="mb-20"><label class="admin-field-label-bold">What does your business do? *</label><textarea id="q_businessDesc" class="form-input" rows="3" required placeholder="Describe your business, products, or services...">${client.questionnaire?.businessDesc || ''}</textarea></div>
<div class="mb-20"><label class="admin-field-label-bold">Who is your target audience? *</label><textarea id="q_targetAudience" class="form-input" rows="2" required placeholder="Age range, interests, demographics...">${client.questionnaire?.targetAudience || ''}</textarea></div>
<div class="mb-20"><label class="admin-field-label-bold">What sets you apart from competitors?</label><textarea id="q_uniqueValue" class="form-input" rows="2" placeholder="Your unique selling proposition...">${client.questionnaire?.uniqueValue || ''}</textarea></div>
<div class="mb-20"><label class="admin-field-label-bold">Brand personality / vibe</label>
<select id="q_brandVibe" class="form-input admin-input">
<option value="">Select a vibe...</option>
<option value="bold" ${client.questionnaire?.brandVibe === 'bold' ? 'selected' : ''}>Bold & Edgy</option>
<option value="elegant" ${client.questionnaire?.brandVibe === 'elegant' ? 'selected' : ''}>Elegant & Sophisticated</option>
<option value="playful" ${client.questionnaire?.brandVibe === 'playful' ? 'selected' : ''}>Playful & Fun</option>
<option value="minimal" ${client.questionnaire?.brandVibe === 'minimal' ? 'selected' : ''}>Clean & Minimal</option>
<option value="luxury" ${client.questionnaire?.brandVibe === 'luxury' ? 'selected' : ''}>Luxury & Premium</option>
<option value="urban" ${client.questionnaire?.brandVibe === 'urban' ? 'selected' : ''}>Urban & Street</option>
<option value="organic" ${client.questionnaire?.brandVibe === 'organic' ? 'selected' : ''}>Natural & Organic</option>
<option value="tech" ${client.questionnaire?.brandVibe === 'tech' ? 'selected' : ''}>Modern & Tech</option>
</select></div>
<div class="mb-20"><label class="admin-field-label-bold">Colors you like or want to avoid</label><input type="text" id="q_colorPrefs" class="form-input" placeholder="e.g., Love red and black, avoid pastels" value="${client.questionnaire?.colorPrefs || ''}"></div>
<div class="mb-20"><label class="admin-field-label-bold">Brands you admire (inspiration)</label><input type="text" id="q_inspiration" class="form-input" placeholder="e.g., Nike, Apple, Supreme..." value="${client.questionnaire?.inspiration || ''}"></div>
<div class="mb-20"><label class="admin-field-label-bold">Timeline / deadline</label><input type="text" id="q_timeline" class="form-input" placeholder="e.g., Need by March 1st, flexible, ASAP..." value="${client.questionnaire?.timeline || ''}"></div>
<div class="mb-20"><label class="admin-field-label-bold">Anything else we should know?</label><textarea id="q_additional" class="form-input" rows="3" placeholder="Other details, preferences, existing assets...">${client.questionnaire?.additional || ''}</textarea></div>
<button type="submit" style="width: 100%; padding: 16px; background: #e11d48; color: #fff; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; font-family: inherit;">${client.questionnaire ? '✅ Update Questionnaire' : '📋 Submit Questionnaire'}</button>
${client.questionnaire ? '<p style="color: #10b981; font-size: 13px; margin-top: 12px; text-align: center;">✅ Questionnaire submitted on ' + new Date(client.questionnaire.submittedAt).toLocaleDateString() + '</p>' : ''}
</form>
</div>
</div>

<!-- PROOFS & APPROVALS SECTION -->
<div id="portalSection-proofs" class="portal-section" style="padding: 32px; display: none;">
<h2 style="font-size: 24px; font-weight: 700; margin-bottom: 8px;">Proofs & Approvals</h2>
<p class="text-muted mb-24">Review your design proofs. Approve when you're happy, or request changes.</p>
${(() => {
    const clientProofs = proofs.filter(pr => pr.clientId == client.id && pr.sentToClient);
    if (clientProofs.length === 0) return '<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 48px; text-align: center;"><div style="font-size: 48px; margin-bottom: 16px;">✅</div><div style="color: #888; font-size: 16px;">No proofs yet</div><div style="color: #666; font-size: 14px; margin-top: 8px;">Design proofs will appear here when your designer sends them for review.</div></div>';
    const pending = clientProofs.filter(p => p.status === 'pending');
    const approved = clientProofs.filter(p => p.status === 'approved');
    const revision = clientProofs.filter(p => p.status === 'revision');
    const statusIcon = s => s === 'approved' ? '✅' : s === 'pending' ? '⏳' : s === 'revision' ? '🔄' : '📄';
    const statusColor = s => s === 'approved' ? '#10b981' : s === 'pending' ? '#f59e0b' : s === 'revision' ? '#ef4444' : '#888';
    let html = '';
    if (pending.length > 0) {
        html += '<h3 style="font-size: 16px; font-weight: 600; margin-bottom: 16px; color: #f59e0b;">⏳ Awaiting Your Review (' + pending.length + ')</h3>';
        html += pending.map(p => '<div style="background: #111; border: 2px solid #f59e0b40; border-radius: 12px; padding: 24px; margin-bottom: 16px;">' +
            '<div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px; margin-bottom: 16px;">' +
            '<div><h3 style="font-size: 18px; font-weight: 600; color: #fff; margin-bottom: 4px;">' + (p.title || p.name || p.fileName || 'Design Proof') + '</h3>' +
            '<div class="text-muted-sm">' + (p.category || p.proofType || 'Proof') + ' • v' + (p.version || 1) + ' • Sent ' + new Date(p.sentAt || p.uploadedAt).toLocaleDateString() + '</div></div>' +
            '<span style="padding: 6px 14px; border-radius: 100px; font-size: 12px; font-weight: 600; background: #f59e0b20; color: #f59e0b;">⏳ Pending Review</span></div>' +
            (p.image || p.fileData ? '<div style="background: #0a0a0a; border: 1px solid #222; border-radius: 8px; overflow: hidden; margin-bottom: 16px; max-height: 400px;"><img src="' + (p.image || p.fileData) + '" style="width: 100%; display: block; object-fit: contain; max-height: 400px;" alt="Proof"></div>' : '') +
            (p.notes ? '<div style="background: #0a0a0a; border: 1px solid #222; border-radius: 8px; padding: 16px; margin-bottom: 16px;"><div class="text-muted fs-12 mb-4">Designer Notes</div><div style="color: #ccc; font-size: 14px;">' + p.notes + '</div></div>' : '') +
            '<div class="flex-gap-12">' +
            '<button onclick="clientRequestProofRevision(' + p.id + ', ' + client.id + ')" style="flex: 1; padding: 14px; background: transparent; border: 1px solid #ef4444; color: #ef4444; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit; font-size: 14px;">🔄 Request Changes</button>' +
            '<button onclick="clientApproveProof(' + p.id + ', ' + client.id + ')" style="flex: 1; padding: 14px; background: #10b981; border: none; color: #fff; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit; font-size: 14px;">✅ Approve</button>' +
            '</div></div>').join('');
    }
    if (approved.length > 0) {
        html += '<h3 style="font-size: 16px; font-weight: 600; margin: 24px 0 16px; color: #10b981;">✅ Approved (' + approved.length + ')</h3>';
        html += approved.map(p => '<div style="background: #111; border: 1px solid #10b98130; border-radius: 12px; padding: 20px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center;"><div><div class="text-bold-white">' + (p.title || p.name || p.fileName || 'Design Proof') + '</div><div style="font-size: 13px; color: #888; margin-top: 4px;">' + (p.category || '') + ' • Approved ' + (p.approvedAt ? new Date(p.approvedAt).toLocaleDateString() : '') + '</div></div><span style="padding: 6px 14px; border-radius: 100px; font-size: 12px; font-weight: 600; background: #10b98120; color: #10b981;">✅ Approved</span></div>').join('');
    }
    if (revision.length > 0) {
        html += '<h3 style="font-size: 16px; font-weight: 600; margin: 24px 0 16px; color: #ef4444;">🔄 Revision In Progress (' + revision.length + ')</h3>';
        html += revision.map(p => '<div style="background: #111; border: 1px solid #ef444430; border-radius: 12px; padding: 20px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center;"><div><div class="text-bold-white">' + (p.title || p.name || p.fileName || 'Design Proof') + '</div><div style="font-size: 13px; color: #888; margin-top: 4px;">Revision #' + (p.revisionCount || 1) + ' • Designer is working on changes</div></div><span style="padding: 6px 14px; border-radius: 100px; font-size: 12px; font-weight: 600; background: #ef444420; color: #ef4444;">🔄 Revising</span></div>').join('');
    }
    return html;
})()}
</div>

<!-- FAQ SECTION -->
<div id="portalSection-faq" class="portal-section" style="padding: 32px; display: none;">
<h2 style="font-size: 24px; font-weight: 700; margin-bottom: 8px;">Frequently Asked Questions</h2>
<p class="text-muted mb-24">Common questions about your project and working with NUI.</p>
<div class="max-w-700">
${[
    { q: "How long does my branding project take?", a: "Brand Kit projects typically take 7–10 business days. Service Brand Identity is 10–14 days, and Product Brand Identity is 14–21 days. Your specific timeline is in your order details." },
    { q: "How do I approve or request changes to my designs?", a: "Go to the <strong>Proofs</strong> tab in your portal. When a proof is ready, you will see Approve and Request Changes buttons. You will also get an email notification when new proofs are available." },
    { q: "How many revisions do I get?", a: "All packages include 2 rounds of revisions. Additional revision rounds can be added for $150 each. We want you to be 100% happy with the final result." },
    { q: "When can I download my final files?", a: "Final files become available in the <strong>Brand Portal</strong> tab after your proofs are approved and payment is complete. You will get all formats: PNG, SVG, PDF, and more." },
    { q: "What file formats will I receive?", a: "You will receive your logo in PNG (transparent + white background), SVG (scalable vector), PDF, and AI/EPS source files. Brand guidelines come as a professional PDF document." },
    { q: "How do I contact my designer?", a: "Click the <strong>Contact Your Designer</strong> button on your Dashboard. You can also reply to any email from us, or call (248) 487-8747 during business hours." },
    { q: "What are your business hours?", a: "We are available Monday–Thursday 1:00 PM – 4:00 PM EST for calls. Fridays are reserved for design work. Email support is available 24/7 and we respond within 1 business day." },
    { q: "Can I add more services to my project?", a: "Absolutely! Contact us through your portal or call (248) 487-8747 to discuss adding services like social media templates, business cards, packaging design, or web design." },
    { q: "What is included in my brand guidelines?", a: "Your brand guidelines document includes: logo usage rules, color palette with hex/RGB/CMYK codes, typography specifications, brand voice guidelines, and dos and donts for brand consistency." },
    { q: "How does payment work?", a: "We offer flexible payment options: pay in full (5% discount), 50/25/25 split, or 3 monthly payments. You can also use <strong>Afterpay</strong> or <strong>Klarna</strong> for 0% interest financing — just click <strong>Pay Now</strong> on any unpaid invoice and choose your plan at checkout." }
].map(function(faq, i) { return '<div style="background: #111; border: 1px solid #222; border-radius: 12px; margin-bottom: 8px; overflow: hidden;"><button onclick="this.parentElement.classList.toggle(\'faq-open\'); var sp=this.querySelectorAll(\'span\'); if(sp.length>1) sp[1].textContent=this.parentElement.classList.contains(\'faq-open\') ? String.fromCharCode(8722) : \'+\';" style="width: 100%; padding: 20px 24px; background: none; border: none; color: #fff; font-size: 15px; font-weight: 600; text-align: left; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit;"><span class="flex-1">' + faq.q + '</span><span style="color: #e11d48; font-size: 20px; margin-left: 16px;">+</span></button><div style="max-height: 0; overflow: hidden; transition: max-height 0.3s ease; padding: 0 24px;"><div style="padding: 0 0 20px 0; color: #aaa; font-size: 14px; line-height: 1.7;">' + faq.a + '</div></div></div>'; }).join("")}
</div>
<style>.faq-open > div:last-child { max-height: 300px !important; }</style>
<div style="background: #111; border: 1px solid #222; border-radius: 12px; padding: 24px; margin-top: 24px; max-width: 700px; text-align: center;">
<p style="color: #888; font-size: 14px; margin-bottom: 12px;">Still have questions?</p>
<div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
<button onclick="openClientMessageDesigner(${client.id})" style="padding: 12px 24px; background: #e11d48; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit;">💬 Message Us</button>
<a href="tel:2484878747" style="padding: 12px 24px; background: transparent; border: 1px solid #333; color: #fff; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">📞 (248) 487-8747</a>
</div>
</div>
</div>

<!-- BRAND PORTAL SECTION (existing content) -->
<div id="portalSection-brand" class="portal-section hidden">

<style>
            /* PORTFOLIO-STYLE BRAND GUIDE CSS */
            .brand-portal-case { background: #080808; border-radius: 8px; overflow: hidden; }
            .brand-portal-tabs { display: flex; border-bottom: 1px solid rgba(255,255,255,0.06); padding: 0 40px; background: rgba(0,0,0,0.5); }
            .brand-portal-tab { padding: 16px 28px; font-size: 11px; font-weight: 700; color: rgba(255,255,255,0.35); cursor: pointer; border-bottom: 2px solid transparent; transition: all 0.3s; text-transform: uppercase; letter-spacing: 2px; }
            .brand-portal-tab:hover { color: rgba(255,255,255,0.6); }
            .brand-portal-tab.active { color: #fff; border-color: ${client.colors[0]}; }
            .brand-portal-panel { display: none; animation: fadeIn 0.4s ease; }
            .brand-portal-panel.active { display: block; }
            .brand-section { margin-bottom: 56px; }
            .brand-section-title { font-size: 11px; color: ${client.colors[0]}; text-transform: uppercase; letter-spacing: 3px; font-weight: 700; margin-bottom: 32px; display: flex; align-items: center; gap: 12px; }
            .brand-section-title::after { content: ''; flex: 1; height: 1px; background: linear-gradient(90deg, ${client.colors[0]}50, transparent); }
            .logo-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
            .logo-box { background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; padding: 0; text-align: center; transition: all 0.3s; aspect-ratio: 4/3; display: flex; flex-direction: column; overflow: hidden; position: relative; }
            .logo-box:hover { border-color: rgba(255,255,255,0.12); transform: scale(1.01); }
            .logo-box-label { font-size: 10px; color: rgba(255,255,255,0.4); text-transform: uppercase; letter-spacing: 2px; padding: 12px 16px; background: rgba(0,0,0,0.9); font-weight: 600; position: absolute; bottom: 0; left: 0; right: 0; z-index: 2; }
            .logo-box-img { flex: 1; display: flex; align-items: center; justify-content: center; padding: 0; position: relative; background: #080808; }
            .logo-box-img img { width: 100%; height: 100%; object-fit: contain; padding: 20px; }
            .logo-placeholder { width: 100%; height: 100%; background: #080808; display: flex; align-items: center; justify-content: center; color: rgba(255,255,255,0.1); font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
            .color-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
            .color-box { aspect-ratio: 1; border-radius: 6px; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; padding: 12px; position: relative; overflow: hidden; }
            .color-box::before { content: ''; position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.7), transparent); }
            .color-hex { position: relative; font-size: 11px; font-weight: 700; color: #fff; letter-spacing: 1px; }
            .font-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
            .font-box { background: #fff; border: 1px solid rgba(0,0,0,0.08); border-radius: 8px; padding: 32px; }
            .font-label { font-size: 10px; color: #888; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 16px; }
            .font-name { font-size: 36px; font-weight: 700; margin-bottom: 8px; color: #000; }
            .font-sample { color: #333; font-size: 14px; line-height: 1.6; }
            .mockup-grid { display: flex; flex-direction: column; gap: 16px; }
            .mockup-row { display: grid; gap: 16px; }
            .mockup-row.full { grid-template-columns: 1fr; }
            .mockup-row.split { grid-template-columns: 1fr 1fr; }
            .mockup-box { background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; overflow: hidden; position: relative; transition: all 0.3s ease; }
            .mockup-box.wide { aspect-ratio: 16/9; }
            .mockup-box.tall { aspect-ratio: 4/5; }
            .mockup-box:hover { transform: scale(1.01); border-color: rgba(255,255,255,0.12); }
            .mockup-box img, .mockup-box video { width: 100%; height: 100%; object-fit: cover; }

            .bg-asset-card { background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; overflow: hidden; position: relative; aspect-ratio: 4/3; cursor: pointer; transition: all 0.3s ease; }
            .bg-asset-card:hover { border-color: rgba(255,255,255,0.15); transform: scale(1.02); }
            .bg-asset-card img { transition: transform 0.3s ease; }
            .bg-asset-card:hover img { transform: scale(1.03); }
            .bg-asset-label { font-size: 10px; color: rgba(255,255,255,0.5); text-transform: uppercase; letter-spacing: 1.5px; padding: 10px 14px; background: linear-gradient(transparent, rgba(0,0,0,0.9)); position: absolute; bottom: 0; left: 0; right: 0; font-weight: 600; }
            .mockup-placeholder { width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: rgba(255,255,255,0.12); font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 2px; gap: 10px; background: #080808; }
            .mockup-placeholder::before { content: '+'; width: 32px; height: 32px; border: 1px solid rgba(255,255,255,0.08); border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 18px; color: rgba(255,255,255,0.1); }
            .results-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
            .result-card { background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 48px 32px; text-align: center; position: relative; overflow: hidden; }
            .result-number { font-size: 64px; font-weight: 900; position: relative; color: ${client.colors[0]}; }
            .result-label { font-size: 11px; color: rgba(255,255,255,0.5); text-transform: uppercase; letter-spacing: 3px; margin-top: 12px; position: relative; }
            .website-preview { border-radius: 8px; overflow: hidden; border: 1px solid rgba(255,255,255,0.08); }
            .website-preview img { width: 100%; display: block; }
            .testimonial-box { background: rgba(0,0,0,0.3); border-left: 3px solid ${client.colors[0]}; padding: 48px; border-radius: 0 8px 8px 0; }
            .testimonial-box p { font-size: 22px; font-style: italic; line-height: 1.7; margin-bottom: 32px; font-weight: 300; }
            .testimonial-author { display: flex; align-items: center; gap: 20px; }
            .testimonial-avatar { width: 48px; height: 48px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: 700; background: ${client.colors[0]}; }
            .proof-approval-bar { background: #111; border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 24px; margin: 24px 48px; }
            .proof-status-badge { display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; border-radius: 100px; font-size: 12px; font-weight: 600; }
            .download-section { background: #0a0a0a; padding: 48px; border-top: 1px solid rgba(255,255,255,0.06); }
            .download-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
            .download-card { background: #1a1a1a; padding: 24px; border-radius: 12px; display: flex; flex-direction: column; justify-content: space-between; min-height: 160px; transition: transform 0.2s; }
            .download-card:hover { transform: translateY(-4px); }
            .download-card h4 { font-size: 16px; font-weight: 600; margin-bottom: 8px; }
            .download-card p { font-size: 13px; color: #888; }
            .download-btn { display: inline-flex; align-items: center; gap: 8px; padding: 12px 0; font-weight: 600; color: #fff; cursor: pointer; border-bottom: 2px solid #fff; transition: gap 0.2s; background: none; border-top: none; border-left: none; border-right: none; font-family: inherit; }
            .download-btn:hover { gap: 14px; }
            .download-btn:disabled { opacity: 0.5; cursor: not-allowed; }
            @media (max-width: 768px) {
                .brand-portal-tabs { padding: 0 16px; flex-wrap: wrap; }
                .brand-portal-tab { padding: 12px 14px; font-size: 9px; }
                .logo-grid { grid-template-columns: 1fr !important; }
                .color-grid { grid-template-columns: repeat(2, 1fr) !important; }
                .font-grid { grid-template-columns: 1fr !important; }
                .mockup-row.split { grid-template-columns: 1fr; }
                .results-grid { grid-template-columns: 1fr !important; }
                .download-grid { grid-template-columns: 1fr !important; }
                .proof-approval-bar { margin: 24px 16px; }
            }
</style>

        <!-- BRAND HERO BANNER (Portfolio Style) -->
<div class="brand-hero" style="width: 100%; min-height: 360px; background: linear-gradient(145deg, ${client.colors[1] || client.colors[0]} 0%, #050505 100%); position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; padding: 60px 40px;">
<div style="position: absolute; inset: 0; background: url('${logos[0]?.data || ''}') center/cover; opacity: 0.15;"></div>
<div style="position: absolute; inset: 0; background: linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.7) 100%);"></div>
<div style="position: relative; text-align: center; z-index: 1; max-width: 100%;">
<div style="font-size: 11px; text-transform: uppercase; letter-spacing: 4px; color: ${client.colors[0]}; margin-bottom: 16px; font-weight: 600;">${client.industry || 'Brand Identity'}</div>
<h2 style="font-size: clamp(32px, 7vw, 80px); font-weight: 900; text-transform: uppercase; letter-spacing: -2px; line-height: 1; color: #fff;">${client.name}</h2>
<p style="color: rgba(255,255,255,0.5); font-size: 15px; margin-top: 20px; max-width: 550px; margin-left: auto; margin-right: auto; line-height: 1.6;">Complete Brand Identity & Digital Presence</p>
</div>
<div style="position: absolute; bottom: 24px; left: 50%; transform: translateX(-50%); display: flex; gap: 6px;">
                ${client.colors.map(c => '<div style="width: 28px; height: 28px; border-radius: 4px; background: ' + c + '; border: 1px solid rgba(255,255,255,0.15);"></div>').join('')}
</div>
</div>

        <!-- MOODBOARD SECTION (for clients) -->
        ${currentUser?.type !== 'admin' ? (() => {
            const moodboards = proofs.filter(p => p.type === 'moodboard' && p.clientId == client.id && p.sentToClient);
            if (moodboards.length === 0) return '';
            const moodboard = moodboards[moodboards.length - 1]; // Latest moodboard
            const statusColors = {
                'approved': { bg: '#10b98120', color: '#10b981', icon: '✓', label: 'Approved' },
                'pending': { bg: '#f59e0b20', color: '#f59e0b', icon: '⏳', label: 'Pending Review' },
                'revision': { bg: '#ef444420', color: '#ef4444', icon: '↻', label: 'Revision Requested' },
                'draft': { bg: '#33333350', color: '#888', icon: '📝', label: 'Draft' }
            };
            const statusInfo = statusColors[moodboard.status] || statusColors.draft;
            return `
<div style="background: #111; border: 1px solid rgba(255,255,255,0.06); border-radius: 16px; padding: 24px; margin: 0 48px 32px 48px;">
<div class="admin-row-between">
<h3 style="font-size: 18px; font-weight: 600; color: #fff; margin: 0;">🎨 Creative Direction — Moodboard</h3>
<div class="proof-status-badge" style="background: ${statusInfo.bg}; color: ${statusInfo.color}; display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; border-radius: 100px; font-size: 12px; font-weight: 600;">
<span>${statusInfo.icon}</span>
                        ${statusInfo.label}
</div>
</div>
                ${moodboard.notes ? `<p style="color: rgba(255,255,255,0.6); margin: 0 0 20px 0; font-size: 14px; line-height: 1.6;">${moodboard.notes}</p>` : ''}
<div style="background: #0a0a0a; border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 24px; margin-bottom: 20px; position: relative; min-height: 400px; overflow: hidden;">
<div style="position: absolute; inset: 0; ${moodboard.canvasBackground ? 'background: ' + moodboard.canvasBackground : 'background: linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)'};"></div>
<div style="position: relative; width: 100%; height: 100%; min-height: 400px;">
                        ${renderMoodboardItems(moodboard)}
</div>
</div>
                ${moodboard.status === 'pending' ? `
<div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
<button onclick="requestMoodboardChanges(${client.id}, ${moodboard.id})" style="background: transparent; border: 1px solid #ef4444; color: #ef4444; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit;">↻ Request Changes</button>
<button onclick="approveMoodboard(${client.id}, ${moodboard.id})" style="background: #10b981; border: none; color: #fff; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit;">✓ Approve Moodboard</button>
</div>
                ` : ''}
                ${moodboard.comments && moodboard.comments.length > 0 ? `
<div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
<div style="font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;">Feedback History</div>
                    ${moodboard.comments.slice(-3).map(c => '<div style="background: #0a0a0a; padding: 12px 16px; border-radius: 8px; margin-bottom: 8px;"><div class="text-muted fs-12 mb-4">' + new Date(c.timestamp).toLocaleDateString() + ' - ' + (c.author || 'Designer') + '</div><div style="font-size: 14px; color: rgba(255,255,255,0.7);">' + c.text + '</div></div>').join('')}
</div>
                ` : ''}
</div>
            `;
        })() : ''}

        <!-- PROOF APPROVAL BAR (for clients) -->
        ${currentUser?.type !== 'admin' ? `
<div class="proof-approval-bar">
<div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
<div>
<div style="font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Proof Status</div>
<div class="proof-status-badge" style="background: ${brandGuide.status === 'approved' ? '#10b98120' : brandGuide.status === 'pending' ? '#f59e0b20' : brandGuide.status === 'revision_requested' ? '#ef444420' : '#33333350'}; color: ${brandGuide.status === 'approved' ? '#10b981' : brandGuide.status === 'pending' ? '#f59e0b' : brandGuide.status === 'revision_requested' ? '#ef4444' : '#888'};">
<span>${brandGuide.status === 'approved' ? '✓' : brandGuide.status === 'pending' ? '⏳' : brandGuide.status === 'revision_requested' ? '↻' : '📝'}</span>
                        ${brandGuide.status === 'approved' ? 'Approved' : brandGuide.status === 'pending' ? 'Pending Review' : brandGuide.status === 'revision_requested' ? 'Revision Requested' : 'Draft'}
</div>
</div>
                ${brandGuide.status === 'pending' ? `
<div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
<button onclick="showRevisionModal(${client.id})" style="background: transparent; border: 1px solid #ef4444; color: #ef4444; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit;">↻ Request Revision</button>
<button onclick="approveClientBrandProof(${client.id})" style="background: #10b981; border: none; color: #fff; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit;">✓ Approve Proof</button>
</div>
                ` : brandGuide.status === 'approved' ? `
<div style="color: #10b981; font-weight: 600;">
                    ${isPaid ? '✓ Your brand assets are ready for download below!' : '⚠️ Complete payment to download your brand assets'}
</div>
                ` : ''}
</div>
            ${brandGuide.proofComments?.length > 0 ? `
<div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
<div style="font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;">Revision History</div>
                ${brandGuide.proofComments.slice(-3).map(c => '<div style="background: #0a0a0a; padding: 12px 16px; border-radius: 8px; margin-bottom: 8px;"><div class="text-muted fs-12 mb-4">' + new Date(c.date).toLocaleDateString() + ' - ' + c.type + '</div><div class="fs-14">' + c.comment + '</div></div>').join('')}
</div>
            ` : ''}
</div>
        ` : ''}

        <!-- PORTFOLIO-STYLE TABS -->
<div class="brand-portal-case">
<div class="brand-portal-tabs">
<div class="brand-portal-tab active" onclick="switchBrandPortalTab(0, this)">Brand Guide</div>
<div class="brand-portal-tab" onclick="switchBrandPortalTab(1, this)">Website / Webapp</div>
<div class="brand-portal-tab" onclick="switchBrandPortalTab(2, this)">Results</div>
<div class="brand-portal-tab" onclick="switchBrandPortalTab(3, this)">Downloads</div>
</div>

            <!-- PANEL 0: BRAND GUIDE -->
<div class="brand-portal-panel active" data-panel="0" style="padding: 48px; background: linear-gradient(180deg, transparent 0%, ${client.colors[1] || client.colors[0]}10 100%);">

                <!-- BRAND VOICE (Slogan & Mission) -->
                ${(client.slogan || client.mission) ? `
<div class="brand-section">
<div class="brand-section-title">Brand Voice</div>
<div style="display: grid; grid-template-columns: ${client.slogan && client.mission ? '1fr 1fr' : '1fr'}; gap: 20px;">
                        ${client.slogan ? '<div style="background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; padding: 32px;"><div style="font-size: 10px; color: ' + client.colors[0] + '; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 16px; font-weight: 600;">Slogan</div><div style="font-size: 24px; font-weight: 700; line-height: 1.3; color: #fff;">&ldquo;' + client.slogan + '&rdquo;</div></div>' : ''}
                        ${client.mission ? '<div style="background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; padding: 32px;"><div style="font-size: 10px; color: ' + client.colors[0] + '; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 16px; font-weight: 600;">Mission Statement</div><div style="font-size: 16px; line-height: 1.7; color: rgba(255,255,255,0.7);">' + client.mission + '</div></div>' : ''}
</div>
</div>
                ` : ''}

                <!-- LOGO SYSTEM -->
                ${buildAssetGallery(client.assets?.logos?.length ? client.assets.logos : logos, 'Logo System', client.colors[0], 3)}

                <!-- COLOR PALETTE -->
<div class="brand-section">
<div class="brand-section-title">Color Palette</div>
<div class="color-grid">
                        ${client.colors.map((c, idx) => '<div class="color-box" style="background: ' + c + ';"><div class="color-hex">' + c.toUpperCase() + '</div></div>').join('')}
                        ${client.colors.length < 4 ? Array(4 - client.colors.length).fill('<div class="color-box" style="background: #1a1a1a;"><div class="color-hex">&mdash;</div></div>').join('') : ''}
</div>
</div>

                <!-- FONT SYSTEM -->
<div class="brand-section">
<div class="brand-section-title">Font System</div>
<div class="font-grid">
<div class="font-box">
<div class="font-label">Heading Font</div>
<div class="font-name" style="font-family: '${client.fonts?.heading || 'Inter'}', sans-serif;">${client.fonts?.heading || 'Inter'}</div>
<div class="font-sample">ABCDEFGHIJKLMNOPQRSTUVWXYZ<br>abcdefghijklmnopqrstuvwxyz<br>0123456789</div>
</div>
<div class="font-box">
<div class="font-label">Body Font</div>
<div class="font-name" style="font-family: '${client.fonts?.body || 'Inter'}', sans-serif;">${client.fonts?.body || 'Inter'}</div>
<div class="font-sample" style="font-family: '${client.fonts?.body || 'Inter'}', sans-serif;">The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs.</div>
</div>
</div>
</div>

                <!-- DYNAMIC ASSET GALLERIES -->
                ${buildAssetGallery(client.assets?.moodboard, 'Moodboard Imagery', client.colors[0], 3)}
                ${buildAssetGallery(client.assets?.mockups, 'Brand Mockups', client.colors[0], 2)}
                ${buildAssetGallery(client.assets?.social, 'Social Media', client.colors[0], 3)}
                ${buildAssetGallery(client.assets?.print, 'Print & Signage', client.colors[0], 3)}
                ${buildAssetGallery(client.assets?.apparel, 'Apparel & Merchandise', client.colors[0], 3)}
                ${buildAssetGallery(client.assets?.digital, 'Digital Marketing', client.colors[0], 3)}
                ${buildAssetGallery(client.assets?.packaging, 'Packaging & Labels', client.colors[0], 3)}
                ${buildAssetGallery(client.assets?.other, 'Additional Assets', client.colors[0], 3)}
                ${buildAssetGallery(client.assets?.documents, 'Documents', client.colors[0], 3)}
</div>

            <!-- PANEL 1: WEBSITE / WEBAPP -->
<div class="brand-portal-panel" data-panel="1" style="padding: 48px; background: linear-gradient(180deg, transparent 0%, ${client.colors[1] || client.colors[0]}10 100%);">
<div class="website-preview" style="border-color: ${client.colors[0]}20; position: relative; margin-bottom: 32px;">
<img loading="lazy" src="${client.websiteScreenshot || logos[0]?.data || ''}" alt="${client.name} Website" style="width: 100%; height: 500px; object-fit: cover; background: #0a0a0a;">
                    ${client.websiteUrl ? '<a href="' + client.websiteUrl + '" target="_blank" style="position: absolute; bottom: 24px; right: 24px; background: ' + client.colors[0] + '; color: #fff; padding: 14px 28px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 14px; display: flex; align-items: center; gap: 8px; transition: transform 0.2s;">Visit Site <span style="font-size: 18px;">→</span></a>' : ''}
</div>
<div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
<p style="color: rgba(255,255,255,0.6); line-height: 1.8; font-size: 16px; flex: 1; min-width: 280px;">A fully responsive, high-converting website designed to capture the essence of ${client.name}. The platform features custom functionality, seamless navigation, and is optimized for both desktop and mobile users.</p>
                    ${client.websiteUrl ? '<a href="' + client.websiteUrl + '" target="_blank" style="background: transparent; border: 1px solid ' + client.colors[0] + '; color: ' + client.colors[0] + '; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 13px; white-space: nowrap;">' + (client.websiteUrl.replace('https://', '').replace('http://', '')) + '</a>' : ''}
</div>
                <!-- Web Mockups Grid -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 32px;">
<div style="aspect-ratio: 4/5; background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; overflow: hidden; display: flex; align-items: center; justify-content: center;">
                        ${client.webMockups?.[0] ? '<img loading="lazy" src="' + client.webMockups[0] + '" alt="Web Mockup" style="width:100%;height:100%;object-fit:cover;">' : '<div style="color: rgba(255,255,255,0.12); font-size: 14px;">Image / Video</div>'}
</div>
<div style="aspect-ratio: 4/5; background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; overflow: hidden; display: flex; align-items: center; justify-content: center;">
                        ${client.webMockups?.[1] ? '<img loading="lazy" src="' + client.webMockups[1] + '" alt="Web Mockup" style="width:100%;height:100%;object-fit:cover;">' : '<div style="color: rgba(255,255,255,0.12); font-size: 14px;">Image / Video</div>'}
</div>
</div>
</div>

            <!-- PANEL 2: RESULTS -->
<div class="brand-portal-panel" data-panel="2" style="padding: 48px; background: linear-gradient(180deg, transparent 0%, ${client.colors[1] || client.colors[0]}10 100%);">
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 48px;">
<div style="background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; padding: 32px;">
<div style="font-size: 12px; text-transform: uppercase; letter-spacing: 2px; color: ${client.colors[0]}; margin-bottom: 16px; font-weight: 600;">Challenge</div>
<p style="color: rgba(255,255,255,0.6); line-height: 1.8; font-size: 15px; margin: 0;">${client.problem || 'The client needed a complete brand transformation to better connect with their target audience and stand out in a competitive market.'}</p>
</div>
<div style="background: #080808; border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; padding: 32px;">
<div style="font-size: 12px; text-transform: uppercase; letter-spacing: 2px; color: ${client.colors[0]}; margin-bottom: 16px; font-weight: 600;">Solution</div>
<p style="color: rgba(255,255,255,0.6); line-height: 1.8; font-size: 15px; margin: 0;">${client.solution || 'We developed a comprehensive brand strategy with modern visual identity, responsive web platform, and targeted digital marketing campaigns.'}</p>
</div>
</div>
<div style="font-size: 12px; text-transform: uppercase; letter-spacing: 2px; color: ${client.colors[0]}; margin-bottom: 24px; font-weight: 600;">Results</div>
<div class="results-grid">
<div class="result-card"><div class="result-number">${client.results?.revenue || '+45%'}</div><div class="result-label">Revenue Growth</div></div>
<div class="result-card"><div class="result-number">${client.results?.traffic || '+120%'}</div><div class="result-label">Web Traffic</div></div>
<div class="result-card"><div class="result-number">${client.results?.engagement || '+85%'}</div><div class="result-label">Engagement</div></div>
</div>
                ${client.testimonial ? `
<div style="margin-top: 48px;">
<div class="testimonial-box">
<p>"${client.testimonial.text || 'Working with NUI transformed our brand completely. The attention to detail and creative vision exceeded our expectations.'}"</p>
<div class="testimonial-author">
<div class="testimonial-avatar">${(client.testimonial.author || client.name).charAt(0)}</div>
<div>
<div style="font-weight: 700;">${client.testimonial.author || client.contact || 'Client'}</div>
<div style="color: rgba(255,255,255,0.5); font-size: 14px;">${client.testimonial.title || 'Owner'}, ${client.name}</div>
</div>
</div>
</div>
</div>
                ` : ''}
</div>

            <!-- PANEL 3: DOWNLOADS -->
<div class="brand-portal-panel" data-panel="3" style="padding: 48px; background: linear-gradient(180deg, transparent 0%, ${client.colors[1] || client.colors[0]}10 100%);">
                ${!isPaid && brandGuide.status !== 'approved' ? `
<div style="background: #1a0a0a; border: 1px solid #ef4444; border-radius: 12px; padding: 32px; text-align: center; margin-bottom: 32px;">
<div style="font-size: 48px; margin-bottom: 16px;">🔒</div>
<h3 style="font-size: 20px; font-weight: 700; margin-bottom: 8px;">Downloads Locked</h3>
<p class="text-muted mb-24">Please approve your brand proofs and complete payment to unlock downloads.</p>
</div>
                ` : ''}
<div class="brand-section-title">Available Downloads</div>
<div class="download-grid">
                    ${logos.length > 0 ? '<div class="download-card" style="background: linear-gradient(135deg, ' + client.colors[0] + ', ' + (client.colors[1] || client.colors[0]) + ');"><div><h4>Logo Pack</h4><p>' + logos.length + ' logo file(s)</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'logos\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
                    ${mockups.length > 0 ? '<div class="download-card" style="background: #2563eb;"><div><h4>Brand Mockups</h4><p>' + mockups.length + ' mockup(s)</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'mockups\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
                    ${videos.length > 0 ? '<div class="download-card" style="background: #dc2626;"><div><h4>Brand Video</h4><p>' + (videos[0]?.size || '1 video') + '</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'video\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
                    ${social.length > 0 ? '<div class="download-card" style="background: linear-gradient(135deg, #7c3aed, #a855f7);"><div><h4>Social Templates</h4><p>' + social.length + ' template(s)</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'social\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
                    ${banners.length > 0 ? '<div class="download-card" style="background: #0891b2;"><div><h4>Banners</h4><p>' + banners.length + ' banner(s)</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'banner\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
                    ${(client.assets?.print?.length > 0) ? '<div class="download-card" style="background: #b45309;"><div><h4>Print & Signage</h4><p>' + client.assets.print.length + ' file(s)</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'print\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
                    ${(client.assets?.apparel?.length > 0) ? '<div class="download-card" style="background: #7c3aed;"><div><h4>Apparel & Merch</h4><p>' + client.assets.apparel.length + ' file(s)</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'apparel\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
                    ${(client.assets?.digital?.length > 0) ? '<div class="download-card" style="background: #0d9488;"><div><h4>Digital Marketing</h4><p>' + client.assets.digital.length + ' file(s)</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'digital\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
                    ${(client.assets?.packaging?.length > 0) ? '<div class="download-card" style="background: #e11d48;"><div><h4>Packaging & Labels</h4><p>' + client.assets.packaging.length + ' file(s)</p></div><button class="download-btn" onclick="downloadAsset(' + client.id + ', \'packaging\', 0)" ' + (!isPaid ? 'disabled' : '') + '>Download ↓</button></div>' : ''}
<div class="download-card" style="background: linear-gradient(135deg, ${client.colors[0]}, ${client.colors[1] || client.colors[0]});"><div><h4>Color Palette</h4><p>${client.colors.join(' • ')}</p></div><button class="download-btn" onclick="copyColors('${client.colors.join(',')}')">Copy Colors 📋</button></div>
</div>
</div>
</div>

        <!-- FOOTER -->
<section style="padding: 48px; background: #000; text-align: center; border-top: 1px solid #222;">
<div style="font-size: 28px; font-weight: 700; margin-bottom: 12px; color: #fff;">${client.name}</div>
<p style="color: #666; font-size: 14px;">Brand Guidelines • ${new Date().getFullYear()}</p>
<p style="color: #333; font-size: 12px; margin-top: 32px;">Powered by NUI Brand Portal</p>
<button onclick="backToAdmin()" style="margin-top: 24px; padding: 12px 24px; background: transparent; border: 1px solid #333; color: #fff; cursor: pointer; border-radius: 4px; font-family: inherit;">← Back</button>
</section>
</div><!-- /portalSection-brand -->
    `;
}

// Note: checkClientPaymentStatus is defined later in the file (line ~12356) with more comprehensive checking

// Switch brand portal tabs
function switchBrandPortalTab(panelIndex, tabEl) {
    const tabs = document.querySelectorAll('.brand-portal-tab');
    tabs.forEach(t => t.classList.remove('active'));
    tabEl.classList.add('active');
    const panels = document.querySelectorAll('.brand-portal-panel');
    panels.forEach(p => p.classList.remove('active'));
    panels[panelIndex].classList.add('active');
}

// Switch main portal sections (Dashboard, Brand, Orders, Info, Questionnaire)
function switchPortalSection(section, clientId) {
    document.querySelectorAll('.portal-section').forEach(s => s.style.display = 'none');
    document.querySelectorAll('.portal-main-tab').forEach(t => { t.style.borderBottomColor = 'transparent'; t.style.color = '#888'; });
    const target = document.getElementById('portalSection-' + section);
    if (target) target.style.display = section === 'brand' ? 'block' : 'block';
    const activeTab = document.querySelector('.portal-main-tab[data-tab="' + section + '"]');
    if (activeTab) { activeTab.style.borderBottomColor = '#e11d48'; activeTab.style.color = '#fff'; }
}

// Submit client questionnaire from portal
function submitClientQuestionnaire(e, clientId) {
    e.preventDefault();
    const client = clients.find(c => c.id === clientId);
    if (!client) return;
    client.questionnaire = {
        businessDesc: document.getElementById('q_businessDesc')?.value || '',
        targetAudience: document.getElementById('q_targetAudience')?.value || '',
        uniqueValue: document.getElementById('q_uniqueValue')?.value || '',
        brandVibe: document.getElementById('q_brandVibe')?.value || '',
        colorPrefs: document.getElementById('q_colorPrefs')?.value || '',
        inspiration: document.getElementById('q_inspiration')?.value || '',
        timeline: document.getElementById('q_timeline')?.value || '',
        additional: document.getElementById('q_additional')?.value || '',
        submittedAt: new Date().toISOString()
    };
    saveClients();
    alert('✅ Questionnaire submitted! We\'ll use this to tailor your brand experience.');
    showClientPortal(client);
}

// Show revision modal for proof feedback
function showRevisionModal(clientId) {
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; inset: 0; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 9999; padding: 20px;';
    modal.innerHTML = `
<div style="background: #111; border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; padding: 32px; max-width: 500px; width: 100%;">
<h3 style="font-size: 20px; font-weight: 700; margin-bottom: 8px; color: #fff;">Request Revision</h3>
<p class="text-muted mb-24">Please describe what changes you'd like to see.</p>
<textarea id="revisionComment" placeholder="Describe the changes needed..." style="width: 100%; min-height: 120px; padding: 16px; background: #0a0a0a; border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #fff; font-family: inherit; font-size: 14px; resize: vertical;"></textarea>
<div style="display: flex; gap: 12px; margin-top: 24px;">
<button onclick="this.closest('div[style*=fixed]').remove()" style="flex: 1; padding: 14px; background: transparent; border: 1px solid #333; color: #fff; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit;">Cancel</button>
<button onclick="submitRevision(${clientId})" style="flex: 1; padding: 14px; background: #ef4444; border: none; color: #fff; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: inherit;">Submit Revision</button>
</div>
</div>
    `;
    document.body.appendChild(modal);
}

// Submit revision request
function submitRevision(clientId) {
    const comment = document.getElementById('revisionComment').value.trim();
    if (!comment) { alert('Please enter your revision comments'); return; }

    const client = clients.find(c => c.id === clientId);
    if (!client.brandGuide) client.brandGuide = { status: 'draft', proofComments: [] };
    client.brandGuide.status = 'revision_requested';
    client.brandGuide.proofComments.push({ type: 'Revision Requested', comment: comment, date: new Date().toISOString() });
    saveClients();

    // UPDATE THE PROOF SYSTEM: Find matching proof and update it
    const clientProof = proofs.find(p => p.type === 'brandguide' && p.clientId == clientId && (p.status === 'pending' || p.status === 'revision'));

    if (clientProof) {
        // Update proof with revision information
        clientProof.status = 'revision';
        clientProof.revisionCount = (clientProof.revisionCount || 0) + 1;
        clientProof.comments = clientProof.comments || [];
        clientProof.comments.push({
            author: client.name || 'Client',
            text: comment,
            timestamp: new Date().toISOString()
        });
        clientProof.updatedAt = new Date().toISOString();
        saveProofs();

        // Notify designer about the revision request
        if (clientProof.designerId) {
            addDesignerMessage(clientProof.designerId, clientProof.projectId, `📝 Client "${client.name}" has requested revisions on "${clientProof.name}": ${comment}`, 'revision', false);
        }

        // Log to CRM
        logProofActivity('revision', clientProof, `Client "${client.name}" requested revisions on "${clientProof.name}"`);
    }

    // Send email notification to admin about revision request
    simulateEmailNotification(
        'admin@newurbaninfluence.com',
        `📝 Revision Requested: ${client.name} - ${clientProof?.name || 'Brand Guide'}`,
        `Client "${client.name}" has requested revisions on "${clientProof?.name || 'their brand guide'}". Revision request:\n\n"${comment}"`
    );

    document.querySelector('div[style*="fixed"][style*="inset"]').remove();
    alert('Revision request submitted! Our team will review and update your proofs.');
    showClientPortal(client);
}

// Approve client brand proof (for client portal)
function approveClientBrandProof(clientId) {
    const client = clients.find(c => c.id === clientId);
    if (!client.brandGuide) client.brandGuide = { status: 'draft', proofComments: [] };

    const isPaid = checkClientPaymentStatus(clientId);
    client.brandGuide.status = 'approved';
    client.brandGuide.proofComments.push({ type: 'Approved', comment: 'Client approved the brand proofs', date: new Date().toISOString() });
    client.brandGuide.approvedAt = new Date().toISOString();
    saveClients();

    // TRIGGER THE FULL APPROVAL WORKFLOW: Find matching proof and call approveProof()
    const clientProof = proofs.find(p => p.type === 'brandguide' && p.clientId == clientId && (p.status === 'pending' || p.status === 'revision'));

    if (clientProof) {
        // Call the existing approveProof() function which handles all the real workflow:
        // - Saves to brand assets
        // - Updates order status
        // - Notifies designer
        // - Sends real email
        // - Logs to CRM
        approveProof(clientProof.id);
    } else {
        // LEGACY DATA: No matching proof found, do manual workflow
        // Send real email notification instead of console.log
        simulateEmailNotification(
            client.email,
            `✅ Your Brand Proofs Have Been Approved!`,
            `Great news! Your brand proofs have been approved. ${isPaid ? 'Your brand assets are now available for download in your client portal.' : 'Complete your payment to unlock the final deliverable files.'}`
        );

        // Log approval to CRM
        const legacyProof = {
            clientId: clientId,
            clientName: client.name,
            name: 'Brand Guide',
            type: 'brandguide',
            id: Date.now()
        };
        logProofActivity('approved', legacyProof, `Client "${client.name}" approved their brand guide`);
    }

    if (isPaid) {
        alert('🎉 Proof Approved! Your brand assets are now available for download.');
    } else {
        alert('Proof Approved! Please complete payment to download your brand assets.');
    }
    showClientPortal(client);
}

// Approve moodboard (for client portal) — Full Approval Cascade
// Merged from nui-system-patch.js Step 4:
//   1. Update moodboard status → approved
//   2. Create formal Supabase approval record (timestamp + client_id)
//   3. Advance project stage to 'Design'
//   4. Log to CRM + notify admin
function approveMoodboard(clientId, moodboardId) {
    if (typeof proofs === 'undefined') return;

    const mb = proofs.find(p => p.id == moodboardId);
    if (!mb) return;

    // Validate: client must own this moodboard
    if (mb.clientId && mb.clientId != clientId) {
        alert('You are not authorized to approve this moodboard.');
        return;
    }

    // 1) Update moodboard status
    mb.status = 'approved';
    mb.approvedAt = new Date().toISOString();
    mb.approved_by = clientId;
    if (typeof saveProofs === 'function') saveProofs();

    // 1.5) SYNC: Extract colors, images, notes → client record + brand guide
    if (typeof syncMoodboardToClient === 'function') {
        syncMoodboardToClient(moodboardId);
    }

    // 2) CREATE FORMAL APPROVAL RECORD in Supabase
    if (typeof supabaseClient !== 'undefined' && mb.project_id) {
        supabaseClient.from('approvals').insert({
            project_id: mb.project_id,
            entity_type: 'moodboard',
            entity_id: mb.id,
            status: 'approved',
            client_id: clientId,
            approved_by: clientId,
            approved_at: new Date().toISOString(),
            metadata: { title: mb.title, clientName: mb.clientName }
        }).then(function(res) {
            if (res.error) console.error('Approval record error:', res.error);
            else console.log('✅ Approval record created for moodboard:', mb.title);
        });
    }

    // 3) ADVANCE PROJECT STAGE to 'Design' (moodboard approved = ready for design)
    if (mb.project_id && typeof projects !== 'undefined') {
        const project = projects.find(p => p.id == mb.project_id);
        if (project) {
            project.stage = 'Design';
            project.activityLog = project.activityLog || [];
            project.activityLog.push({
                action: 'Moodboard approved — stage advanced to Design',
                timestamp: new Date().toISOString(),
                stage: 'Design',
                entity: 'moodboard',
                entityId: mb.id
            });
            if (typeof saveProjects === 'function') saveProjects();
            console.log('✅ Project stage updated to Design');
        }
    }

    // 4) Log to CRM
    if (typeof logProofActivity === 'function') {
        logProofActivity('approved', mb.clientName || 'Client', mb.title + ' moodboard approved by client');
    }

    // 5) Notify admin via email
    if (typeof simulateEmailNotification === 'function') {
        simulateEmailNotification(
            'newurbaninfluence@gmail.com',
            'Moodboard Approved: ' + mb.title,
            '<h2>Moodboard Approved</h2><p>' + (mb.clientName || 'Client') +
            ' has approved the moodboard: <strong>' + mb.title +
            '</strong></p><p>Project stage advanced to Design. You can now proceed with the brand guide.</p>'
        );
    }

    alert('Moodboard approved! Your designer will begin working on your brand guide.');

    // Refresh portal
    const client = clients.find(c => c.id == clientId);
    if (client && typeof showClientPortal === 'function') {
        showClientPortal(client);
    }
}

// Request moodboard changes (for client portal)
function requestMoodboardChanges(clientId, moodboardId) {
    const feedback = prompt('What changes would you like? Describe your feedback:');
    if (!feedback || !feedback.trim()) return;

    const mb = proofs.find(p => p.id == moodboardId);
    if (!mb) return;

    mb.status = 'revision';
    mb.revisionCount = (mb.revisionCount || 0) + 1;
    if (!mb.comments) mb.comments = [];
    mb.comments.push({ author: mb.clientName || 'Client', text: feedback.trim(), timestamp: new Date().toISOString() });
    mb.updatedAt = new Date().toISOString();
    saveProofs();

    // Notify admin
    if (typeof simulateEmailNotification === 'function') {
        simulateEmailNotification('newurbaninfluence@gmail.com', 'Moodboard Revision Request: ' + mb.title,
            '<h2>Revision Requested</h2><p>' + (mb.clientName || 'Client') + ' has requested changes to the moodboard: <strong>' + mb.title + '</strong></p><p><strong>Feedback:</strong> ' + feedback.trim() + '</p>');
    }

    // Log to CRM
    if (typeof logProofActivity === 'function') {
        logProofActivity('revision', mb.clientName || 'Client', 'Moodboard revision requested: ' + feedback.trim());
    }

    alert('Your feedback has been sent to the design team!');

    const client = clients.find(c => c.id == clientId);
    if (client) showClientPortal(client);
}

// ── Client approves a specific proof (from Projects tab) ───────────
function clientApproveProof(proofId, clientId) {
    const proof = (typeof proofs !== 'undefined') ? proofs.find(p => p.id == proofId) : null;
    if (!proof) { alert('Proof not found.'); return; }
    proof.status = 'approved';
    proof.approvedAt = new Date().toISOString();
    if (typeof saveProofs === 'function') saveProofs();
    if (typeof approveProof === 'function') approveProof(proofId);
    alert('✅ Proof approved! Your designer has been notified.');
    const client = (typeof clients !== 'undefined') ? clients.find(c => c.id == clientId) : null;
    if (client) showClientPortal(client);
}

// ── Client requests revision on a specific proof ───────────────────
function clientRequestProofRevision(proofId, clientId) {
    const comment = prompt('What changes would you like? Please describe:');
    if (!comment || !comment.trim()) return;
    const proof = (typeof proofs !== 'undefined') ? proofs.find(p => p.id == proofId) : null;
    if (!proof) { alert('Proof not found.'); return; }
    proof.status = 'revision';
    proof.revisionCount = (proof.revisionCount || 0) + 1;
    proof.comments = proof.comments || [];
    proof.comments.push({ author: 'Client', text: comment.trim(), timestamp: new Date().toISOString() });
    proof.updatedAt = new Date().toISOString();
    if (typeof saveProofs === 'function') saveProofs();
    if (typeof simulateEmailNotification === 'function') {
        simulateEmailNotification('newurbaninfluence@gmail.com', '🔄 Revision Requested: ' + proof.name, 'Client requested revisions on "' + proof.name + '":\n\n' + comment.trim());
    }
    alert('Revision request sent! Your designer will make the updates.');
    const client = (typeof clients !== 'undefined') ? clients.find(c => c.id == clientId) : null;
    if (client) showClientPortal(client);
}

// ── Website feedback modal (from Projects tab) ─────────────────────
function openProjectFeedback(projectId, clientId) {
    const existing = document.getElementById('projectFeedbackModal');
    if (existing) existing.remove();
    const modal = document.createElement('div');
    modal.id = 'projectFeedbackModal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.85);display:flex;align-items:center;justify-content:center;z-index:10000;padding:20px;';
    modal.innerHTML = '<div style="background:#111;border:1px solid #333;border-radius:20px;padding:32px;max-width:520px;width:100%;">'
        + '<h3 style="font-size:20px;font-weight:700;margin-bottom:8px;color:#fff;">💬 Leave Feedback</h3>'
        + '<p style="color:#888;font-size:14px;margin-bottom:20px;">Tell us what you love, what needs tweaking, or any requests for the site.</p>'
        + '<select id="pfCategory" class="form-input" style="width:100%;margin-bottom:12px;">'
        + '<option value="general">General Feedback</option>'
        + '<option value="content">Content / Copy</option>'
        + '<option value="design">Design / Visuals</option>'
        + '<option value="functionality">Functionality / Feature Request</option>'
        + '<option value="bug">Bug Report</option>'
        + '</select>'
        + '<textarea id="pfText" placeholder="Share your thoughts..." style="width:100%;min-height:120px;padding:14px;background:#0a0a0a;border:1px solid #333;border-radius:8px;color:#fff;font-family:inherit;font-size:14px;resize:vertical;margin-bottom:16px;"></textarea>'
        + '<div style="display:flex;gap:12px;">'
        + '<button onclick="document.getElementById(\'projectFeedbackModal\').remove()" style="flex:1;padding:14px;background:transparent;border:1px solid #333;color:#aaa;border-radius:8px;cursor:pointer;font-weight:600;font-family:inherit;">Cancel</button>'
        + '<button onclick="_submitProjectFeedback(' + projectId + ',' + clientId + ')" style="flex:1;padding:14px;background:#3b82f6;border:none;color:#fff;border-radius:8px;cursor:pointer;font-weight:600;font-family:inherit;">Send Feedback</button>'
        + '</div></div>';
    document.body.appendChild(modal);
}

function _submitProjectFeedback(projectId, clientId) {
    const text = (document.getElementById('pfText')?.value || '').trim();
    const category = document.getElementById('pfCategory')?.value || 'general';
    if (!text) { alert('Please enter your feedback.'); return; }
    const project = (typeof projects !== 'undefined') ? projects.find(p => p.id == projectId) : null;
    const client  = (typeof clients  !== 'undefined') ? clients.find(c => c.id == clientId)  : null;
    if (project) {
        project.activityLog = project.activityLog || [];
        project.activityLog.push({ action: '[' + category + '] Client feedback: ' + text, timestamp: new Date().toISOString() });
        if (typeof saveProjects === 'function') saveProjects();
    }
    if (typeof simulateEmailNotification === 'function') {
        simulateEmailNotification('newurbaninfluence@gmail.com',
            '💬 Website Feedback: ' + (project?.name || 'Project #' + projectId) + ' — ' + category,
            'Client: ' + (client?.name || clientId) + '\nCategory: ' + category + '\n\n' + text);
    }
    document.getElementById('projectFeedbackModal').remove();
    alert('✅ Feedback sent! We\'ll review it and follow up.');
}
async function portalPayInvoice(invoiceId) {
    try {
        // Find the invoice from global data
        var invoice = (typeof invoices !== 'undefined' ? invoices : []).find(function(i) { return i.id == invoiceId; });
        if (!invoice) {
            alert('Invoice not found. Please contact your designer.');
            return;
        }
        var client = (typeof clients !== 'undefined' ? clients : []).find(function(c) { return c.id == invoice.clientId; });
        var amount = invoice.total || invoice.amount || 0;
        if (!amount) {
            alert('No amount due on this invoice.');
            return;
        }

        // Determine if this invoice has pay-later or subscription settings
        var billingType = invoice.billingType || 'one_time';
        var payLater = invoice.payLater || 'none';
        // Default to afterpay if not set — always offer financing
        if (payLater === 'none') payLater = 'afterpay';

        var btn = event.target;
        btn.textContent = 'Loading...';
        btn.disabled = true;

        var resp = await fetch('/.netlify/functions/create-subscription', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                clientEmail: client?.email || '',
                clientName: client?.name || '',
                clientId: String(invoice.clientId || ''),
                amount: amount,
                description: invoice.description || invoice.projectName || 'NUI Invoice #' + (invoice.invoiceNumber || invoice.id),
                invoiceId: String(invoiceId),
                billingType: billingType,
                billingCycles: invoice.billingCycles || 0,
                payLater: payLater
            })
        });
        var data = await resp.json();
        if (data.url) {
            window.location.href = data.url;
        } else {
            throw new Error(data.error || 'Could not create checkout session');
        }
    } catch (err) {
        console.error('portalPayInvoice error:', err);
        alert('Payment error: ' + err.message + '. Please try again or contact your designer.');
        if (event && event.target) {
            event.target.textContent = 'Pay Now →';
            event.target.disabled = false;
        }
    }
}

