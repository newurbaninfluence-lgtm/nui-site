module.exports = require('./netlify/functions/sms-drip.js')
