// netlify/functions/openphone-webhook.js
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;
var supaHeaders = {
  "apikey": SUPABASE_KEY,
  "Authorization": `Bearer ${SUPABASE_KEY}`,
  "Content-Type": "application/json"
};
async function findContactByPhone(phone) {
  if (!phone) return null;
  const digits = phone.replace(/\D/g, "").slice(-10);
  if (digits.length < 10) return null;
  const e164 = `+1${digits}`;
  const formats = [phone, e164, digits, `1${digits}`];
  const orFilter = formats.map((f) => `phone.eq.${encodeURIComponent(f)}`).join(",");
  const resp = await fetch(
    `${SUPABASE_URL}/rest/v1/crm_contacts?or=(${orFilter})&select=id,phone,first_name,last_name,status&limit=1`,
    { headers: supaHeaders }
  );
  const rows = await resp.json();
  return rows?.length > 0 ? rows[0] : null;
}
async function createContact(phone, source) {
  const resp = await fetch(`${SUPABASE_URL}/rest/v1/crm_contacts`, {
    method: "POST",
    headers: { ...supaHeaders, "Prefer": "return=representation" },
    body: JSON.stringify({
      phone,
      source: source || "quo_unknown",
      status: "new_lead",
      last_activity_at: (/* @__PURE__ */ new Date()).toISOString()
    })
  });
  const rows = await resp.json();
  return Array.isArray(rows) ? rows[0] : rows;
}
async function logActivity(contactId, type, direction, content, metadata) {
  await fetch(`${SUPABASE_URL}/rest/v1/activity_log`, {
    method: "POST",
    headers: { ...supaHeaders, "Prefer": "return=minimal" },
    body: JSON.stringify({
      contact_id: contactId,
      type,
      direction,
      content: content || "",
      metadata: metadata || {},
      read: false,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    })
  });
}
async function touchContact(contactId) {
  await fetch(`${SUPABASE_URL}/rest/v1/crm_contacts?id=eq.${contactId}`, {
    method: "PATCH",
    headers: { ...supaHeaders, "Prefer": "return=minimal" },
    body: JSON.stringify({ last_activity_at: (/* @__PURE__ */ new Date()).toISOString() })
  });
}
function extractPhone(obj, direction) {
  if (!obj) return null;
  if (direction === "incoming" || direction === "inbound") return obj.from;
  if (direction === "outgoing" || direction === "outbound") return obj.to;
  return obj.from || obj.to;
}
async function ensureContact(phone, source) {
  if (!phone) return null;
  let contact = await findContactByPhone(phone);
  if (!contact) {
    contact = await createContact(phone, source);
    console.log(`[NUI] New contact created: ${phone} \u2192 ${contact?.id}`);
  }
  return contact;
}
async function handleMessageReceived(obj) {
  const phone = obj.from;
  const contact = await ensureContact(phone, "quo_text");
  if (!contact) return { action: "message_received_no_phone" };
  await logActivity(contact.id, "text", "inbound", obj.body || "", {
    quo_message_id: obj.id,
    from: obj.from,
    to: obj.to,
    media: obj.media || [],
    conversation_id: obj.conversationId,
    phone_number_id: obj.phoneNumberId
  });
  await touchContact(contact.id);
  return { action: "message_received", contactId: contact.id };
}
async function handleMessageDelivered(obj) {
  const phone = obj.to;
  const contact = await ensureContact(phone, "quo_text");
  if (!contact) return { action: "message_delivered_no_phone" };
  await logActivity(contact.id, "text", "outbound", obj.body || "", {
    quo_message_id: obj.id,
    from: obj.from,
    to: obj.to,
    status: obj.status,
    conversation_id: obj.conversationId
  });
  await touchContact(contact.id);
  return { action: "message_delivered", contactId: contact.id };
}
async function handleCallRinging(obj) {
  const phone = extractPhone(obj, obj.direction);
  const contact = await ensureContact(phone, "quo_call");
  if (!contact) return { action: "call_ringing_no_phone" };
  await logActivity(
    contact.id,
    "call_ringing",
    obj.direction === "incoming" ? "inbound" : "outbound",
    `Incoming call from ${obj.from}`,
    {
      quo_call_id: obj.id,
      from: obj.from,
      to: obj.to,
      direction: obj.direction
    }
  );
  return { action: "call_ringing", contactId: contact.id };
}
async function handleCallCompleted(obj) {
  const phone = extractPhone(obj, obj.direction);
  const contact = await ensureContact(phone, "quo_call");
  if (!contact) return { action: "call_completed_no_phone" };
  let durationSec = null;
  if (obj.answeredAt && obj.completedAt) {
    durationSec = Math.round((new Date(obj.completedAt) - new Date(obj.answeredAt)) / 1e3);
  }
  const wasAnswered = !!obj.answeredAt;
  const durationDisplay = durationSec ? `${Math.floor(durationSec / 60)}m ${durationSec % 60}s` : "missed";
  const dirLabel = obj.direction === "incoming" ? "Inbound" : "Outbound";
  const content = wasAnswered ? `${dirLabel} call \u2014 ${durationDisplay}` : `${dirLabel} call \u2014 missed/unanswered`;
  await logActivity(contact.id, "call", obj.direction === "incoming" ? "inbound" : "outbound", content, {
    quo_call_id: obj.id,
    from: obj.from,
    to: obj.to,
    direction: obj.direction,
    status: obj.status,
    answered: wasAnswered,
    duration_seconds: durationSec,
    created_at: obj.createdAt,
    answered_at: obj.answeredAt,
    completed_at: obj.completedAt,
    voicemail: obj.voicemail,
    conversation_id: obj.conversationId
  });
  await touchContact(contact.id);
  return { action: "call_completed", contactId: contact.id, answered: wasAnswered, duration: durationSec };
}
async function handleCallSummary(obj) {
  const callId = obj.callId;
  const resp = await fetch(
    `${SUPABASE_URL}/rest/v1/activity_log?metadata->>quo_call_id=eq.${callId}&type=eq.call&select=contact_id&limit=1`,
    { headers: supaHeaders }
  );
  const rows = await resp.json();
  const contactId = rows?.[0]?.contact_id;
  if (!contactId) {
    console.log(`[NUI] call.summary: no matching call found for ${callId}`);
    return { action: "call_summary_orphaned", callId };
  }
  const summaryText = Array.isArray(obj.summary) ? obj.summary.join("\n") : obj.summary || "";
  const nextStepsText = Array.isArray(obj.nextSteps) ? obj.nextSteps.join("\n") : obj.nextSteps || "";
  const content = `Summary: ${summaryText}${nextStepsText ? "\n\nNext Steps: " + nextStepsText : ""}`;
  await logActivity(contactId, "sona_summary", "internal", content, {
    call_id: callId,
    summary: obj.summary,
    next_steps: obj.nextSteps,
    status: obj.status
  });
  await fetch(`${SUPABASE_URL}/rest/v1/crm_contacts?id=eq.${contactId}`, {
    method: "PATCH",
    headers: { ...supaHeaders, "Prefer": "return=minimal" },
    body: JSON.stringify({ sona_qualified: true, last_activity_at: (/* @__PURE__ */ new Date()).toISOString() })
  });
  return { action: "call_summary_logged", contactId };
}
async function handleCallTranscript(obj) {
  const callId = obj.callId;
  const resp = await fetch(
    `${SUPABASE_URL}/rest/v1/activity_log?metadata->>quo_call_id=eq.${callId}&type=eq.call&select=contact_id&limit=1`,
    { headers: supaHeaders }
  );
  const rows = await resp.json();
  const contactId = rows?.[0]?.contact_id;
  if (!contactId) return { action: "call_transcript_orphaned", callId };
  let transcriptText = "";
  if (typeof obj.transcript === "string") {
    transcriptText = obj.transcript;
  } else if (Array.isArray(obj.dialogue || obj.transcript)) {
    const dialogue = obj.dialogue || obj.transcript;
    transcriptText = dialogue.map((d) => `${d.speaker || d.role || "?"}: ${d.content || d.text || ""}`).join("\n");
  }
  await logActivity(contactId, "transcript", "internal", transcriptText, {
    call_id: callId,
    raw_transcript: obj.transcript || obj.dialogue
  });
  return { action: "call_transcript_logged", contactId };
}
async function handleCallRecording(obj) {
  const callId = obj.callId;
  const resp = await fetch(
    `${SUPABASE_URL}/rest/v1/activity_log?metadata->>quo_call_id=eq.${callId}&type=eq.call&select=contact_id&limit=1`,
    { headers: supaHeaders }
  );
  const rows = await resp.json();
  const contactId = rows?.[0]?.contact_id;
  if (!contactId) return { action: "call_recording_orphaned", callId };
  await logActivity(contactId, "recording", "internal", "Call recording available", {
    call_id: callId,
    recording_url: obj.url || obj.recordingUrl,
    duration: obj.duration
  });
  return { action: "call_recording_logged", contactId };
}
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  if (!SUPABASE_URL || !SUPABASE_KEY) {
    console.error("[NUI] Missing SUPABASE_URL or SUPABASE_SERVICE_KEY");
    return { statusCode: 500, body: JSON.stringify({ error: "Server not configured" }) };
  }
  try {
    const payload = JSON.parse(event.body || "{}");
    const eventType = payload.type;
    const obj = payload.data?.object || {};
    console.log(`[NUI] Quo webhook: ${eventType} | id: ${payload.id}`);
    let result;
    switch (eventType) {
      case "message.received":
        result = await handleMessageReceived(obj);
        break;
      case "message.delivered":
        result = await handleMessageDelivered(obj);
        break;
      case "call.ringing":
        result = await handleCallRinging(obj);
        break;
      case "call.completed":
        result = await handleCallCompleted(obj);
        break;
      case "call.summary.completed":
        result = await handleCallSummary(obj);
        break;
      case "call.transcript.completed":
        result = await handleCallTranscript(obj);
        break;
      case "call.recording.completed":
        result = await handleCallRecording(obj);
        break;
      default:
        console.log(`[NUI] Unhandled event type: ${eventType}`);
        result = { action: "unhandled", type: eventType };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, ...result })
    };
  } catch (err) {
    console.error("[NUI] Webhook error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || "Webhook processing failed" })
    };
  }
};
