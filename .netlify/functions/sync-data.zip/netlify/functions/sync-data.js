// netlify/functions/sync-data.js
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
var TABLE_MAP = {
  orders: "orders",
  clients: "clients",
  invoices: "invoices",
  proofs: "proofs",
  projects: "projects",
  leads: "leads",
  crm: "crm_contacts",
  communications: "communications",
  services: "services",
  meetings: "meetings",
  submissions: "submissions"
};
var CONFIG_TYPES = ["site_images", "about", "portfolio"];
async function supabaseFetch(url, serviceKey, path, options = {}) {
  const resp = await fetch(`${url}/rest/v1/${path}`, {
    headers: {
      "apikey": serviceKey,
      "Authorization": `Bearer ${serviceKey}`,
      "Content-Type": "application/json",
      ...options.headers
    },
    ...options
  });
  return resp;
}
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS_HEADERS, body: "" };
  }
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Supabase not configured. Set SUPABASE_URL and SUPABASE_SERVICE_KEY." })
    };
  }
  try {
    if (event.httpMethod === "GET") {
      const syncData = {};
      for (const [key, table] of Object.entries(TABLE_MAP)) {
        try {
          const resp = await supabaseFetch(
            SUPABASE_URL,
            SUPABASE_SERVICE_KEY,
            `${table}?select=*&order=created_at.desc&limit=1000`
          );
          if (resp.ok) {
            const data = await resp.json();
            syncData[key] = { data, count: data.length, lastSync: (/* @__PURE__ */ new Date()).toISOString() };
          } else {
            syncData[key] = { data: [], count: 0, error: `Table ${table}: ${resp.status}` };
          }
        } catch (err) {
          syncData[key] = { data: [], count: 0, error: err.message };
        }
      }
      for (const configType of CONFIG_TYPES) {
        try {
          const resp = await supabaseFetch(
            SUPABASE_URL,
            SUPABASE_SERVICE_KEY,
            `site_config?select=value&key=eq.${configType}&limit=1`
          );
          if (resp.ok) {
            const rows = await resp.json();
            if (rows.length > 0) {
              syncData[configType] = { data: rows[0].value, lastSync: (/* @__PURE__ */ new Date()).toISOString() };
            } else {
              syncData[configType] = { data: null, lastSync: (/* @__PURE__ */ new Date()).toISOString() };
            }
          } else {
            syncData[configType] = { data: null, error: "site_config table not ready" };
          }
        } catch (err) {
          syncData[configType] = { data: null, error: err.message };
        }
      }
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, syncData, syncedAt: (/* @__PURE__ */ new Date()).toISOString() })
      };
    }
    if (event.httpMethod === "POST") {
      const { type, data, syncedBy } = JSON.parse(event.body || "{}");
      if (!type || data === void 0) {
        return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ error: "Missing type or data" }) };
      }
      if (CONFIG_TYPES.includes(type)) {
        const resp2 = await supabaseFetch(SUPABASE_URL, SUPABASE_SERVICE_KEY, "site_config", {
          method: "POST",
          headers: {
            "Prefer": "resolution=merge-duplicates,return=minimal"
          },
          body: JSON.stringify({
            key: type,
            value: data,
            updated_at: (/* @__PURE__ */ new Date()).toISOString()
          })
        });
        if (!resp2.ok) {
          const errBody = await resp2.text();
          console.warn(`Config sync for ${type}:`, resp2.status, errBody);
        }
        return {
          statusCode: 200,
          headers: CORS_HEADERS,
          body: JSON.stringify({ success: true, type, syncedAt: (/* @__PURE__ */ new Date()).toISOString() })
        };
      }
      const table = TABLE_MAP[type];
      if (!table) {
        return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ error: `Unknown data type: ${type}` }) };
      }
      const records = Array.isArray(data) ? data : [data];
      const enrichedRecords = records.map((r) => ({
        ...r,
        synced_at: (/* @__PURE__ */ new Date()).toISOString(),
        synced_by: syncedBy || "system"
      }));
      const resp = await supabaseFetch(SUPABASE_URL, SUPABASE_SERVICE_KEY, table, {
        method: "POST",
        headers: {
          "Prefer": "resolution=merge-duplicates,return=minimal"
        },
        body: JSON.stringify(enrichedRecords)
      });
      if (!resp.ok) {
        const errBody = await resp.text();
        throw new Error(`Supabase upsert failed for ${table}: ${resp.status} - ${errBody}`);
      }
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, type, count: records.length, syncedAt: (/* @__PURE__ */ new Date()).toISOString() })
      };
    }
    return { statusCode: 405, headers: CORS_HEADERS, body: JSON.stringify({ error: "Method not allowed" }) };
  } catch (err) {
    console.error("sync-data error:", err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: err.message || "Sync failed" })
    };
  }
};
